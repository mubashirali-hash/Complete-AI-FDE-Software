# Mission 25 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] Important record counts, relationships and meanings are compared before and after.
- [ ] Required permissions and privacy/retention decisions survive or have an explicit migration policy.
- [ ] A restoration is actually demonstrated and the required user journey is verified afterwards.

## Understanding demonstrations

### explain
Explain migration, backup, restoration and compatibility in your change.

Your reasoning and evidence:

### locate
Find the actual stored format, dependency version and recovery copy.

Your reasoning and evidence:

### predict
What if an older app reads the newly migrated data?

Your reasoning and evidence:

### compare
Compare rollback, forward correction and restoring a backup for this situation.

Your reasoning and evidence:

### challenge
AI says a backup's filename proves recoverability. What demonstration is needed?

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
