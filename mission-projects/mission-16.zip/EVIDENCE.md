# Mission 16 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] The delegated task specifies outcome, context, authority, budget and stopping conditions.
- [ ] The change meets prewritten acceptance criteria with identifiable observations.
- [ ] The record distinguishes agent actions, learner decisions, unrun checks and remaining gaps.

## Understanding demonstrations

### explain
Explain how this task permits autonomy without leaving authority ambiguous.

Your reasoning and evidence:

### locate
Find the evidence connecting the agent's changes to the requested outcome.

Your reasoning and evidence:

### predict
What should happen if the plan needs access outside its allowed scope?

Your reasoning and evidence:

### compare
Compare prescribing every edit with delegating an accepted outcome.

Your reasoning and evidence:

### challenge
AI says its own successful summary is sufficient acceptance evidence. How would you investigate?

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
