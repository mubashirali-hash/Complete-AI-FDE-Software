# Mission 20 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] The comparison uses the same versioned cases and separates held-out cases from tuning.
- [ ] The report includes counts, error types, latency and actual or clearly hypothetical cost.
- [ ] The conclusion explains sample limitations, base rates and what evidence does not establish.

## Understanding demonstrations

### explain
Explain baseline, held-out case, base rate, precision and recall with your results.

Your reasoning and evidence:

### locate
Find raw observations supporting a number in the report.

Your reasoning and evidence:

### predict
What might happen to precision if the target condition becomes much rarer?

Your reasoning and evidence:

### compare
Compare a faster cheaper option with a better-scoring option using the cost of errors.

Your reasoning and evidence:

### challenge
AI says a correlation between using the tool and fewer missed visits proves causation. What else could explain it?

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
