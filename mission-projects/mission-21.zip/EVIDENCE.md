# Mission 21 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] Each important check has a requirement-derived expectation and suitable test data.
- [ ] A deliberate or observed defect produces a meaningful failing check.
- [ ] The fix passes the original expectation and relevant regression checks without hiding the failure.

## Understanding demonstrations

### explain
Explain the different evidence from unit, integration and journey checks.

Your reasoning and evidence:

### locate
Show the expectation that exposed your defect and its source requirement.

Your reasoning and evidence:

### predict
What would still pass if the wrong visit changed but the toast looked correct?

Your reasoning and evidence:

### compare
Compare a faster isolated check with a broader journey check.

Your reasoning and evidence:

### challenge
AI says all green means there are no bugs. Name an untested behaviour and how to investigate it.

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
