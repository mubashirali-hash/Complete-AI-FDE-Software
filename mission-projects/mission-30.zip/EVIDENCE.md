# Mission 30 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] The demonstrated product addresses an evidenced or explicitly labelled scenario problem with proportionate outcome checks.
- [ ] The learner explains the actual stack, runtime, action flow, data, authority, choices and failure behaviour.
- [ ] A fresh condition is investigated and handled with AI available; the review records observed reasoning, limits and next practice.

## Understanding demonstrations

### explain
Explain the purpose, system and important decisions without relying on a prepared script.

Your reasoning and evidence:

### locate
Trace one reviewer-chosen action through the actual technologies and evidence.

Your reasoning and evidence:

### predict
Predict an unfamiliar requirement or failure before asking AI to implement the response.

Your reasoning and evidence:

### compare
Defend an important choice when cost, access or the business goal changes.

Your reasoning and evidence:

### challenge
AI claims completion proves the equivalent of five years' experience. Explain why the evidence supports only the demonstrated capabilities.

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
