# Current tool and environment record

Verification date:
AI builder/agent and model, if known:
Actual languages / runtimes / frameworks / libraries / versions:
Actual database / services / hosting (or absent):
Start / build / test / deployment instructions:
Configuration names (never secret values):
Observed capability and relevant limits:
Provider pricing source + date, or cost explicitly unknown:
Budget, authority and stopping conditions:
Real observations versus fixtures / simulations / unrun checks:
Replacement or export route:
