# Explain the system you actually built

Write or transcribe in your own words. AI may help inspect and teach. A generated explanation alone is insufficient; demonstrate that you can apply the concepts. Update this after meaningful changes. A static site can have no database, accounts, server or live AI.

## Purpose and success

Your explanation, actual component/configuration evidence and useful diagram:

## Actual technologies

Your explanation, actual component/configuration evidence and useful diagram:

## How the parts fit

Your explanation, actual component/configuration evidence and useful diagram:

## Choices and alternatives

Your explanation, actual component/configuration evidence and useful diagram:

## Where it runs

Your explanation, actual component/configuration evidence and useful diagram:

## One action, end to end

Your explanation, actual component/configuration evidence and useful diagram:

## Information, access and AI

Your explanation, actual component/configuration evidence and useful diagram:

## Changes and failures

Your explanation, actual component/configuration evidence and useful diagram:

Do not put secrets or private customer data here.
