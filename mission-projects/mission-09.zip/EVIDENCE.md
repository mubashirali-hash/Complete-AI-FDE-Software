# Mission 9 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] Both approaches are compared using the same workflow and cost criteria.
- [ ] Important capability and pricing claims have dated sources or explicit unknowns.
- [ ] The selected trial has an exit/export plan and a reason to revisit the choice.

## Understanding demonstrations

### explain
Explain your approach and who owns each responsibility.

Your reasoning and evidence:

### locate
Find an integration boundary or the reason no integration is needed.

Your reasoning and evidence:

### predict
What happens if the provider removes a necessary export?

Your reasoning and evidence:

### compare
Defend the chosen approach against the strongest alternative, including maintenance.

Your reasoning and evidence:

### challenge
AI says free code generation makes ongoing cost zero. Name the missing costs and how to estimate them.

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
