# Mission 7 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] The brief defines the outcome, eligible cases and source of its baseline or measurement plan.
- [ ] In-scope and out-of-scope work are explicit, with one priority tradeoff.
- [ ] A guardrail and alternative explanations prevent a misleading success claim.

## Understanding demonstrations

### explain
Explain the baseline, denominator and guardrail in your brief.

Your reasoning and evidence:

### locate
Show the decision that limits the first release.

Your reasoning and evidence:

### predict
If visits double but missed visits stay constant, what happens to the rate?

Your reasoning and evidence:

### compare
Compare logins, completed confirmations and missed visits as success measures.

Your reasoning and evidence:

### challenge
AI says the app caused improvement because results improved after release. What else would you investigate?

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
