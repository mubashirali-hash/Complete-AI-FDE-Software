# Mission 10 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] The matrix distinguishes expected results from observations and unrun checks.
- [ ] It includes a normal, boundary and failure case with specific record identities.
- [ ] At least one deliberate prototype defect or missing behaviour is identified by a check.

## Understanding demonstrations

### explain
Explain why expectations should come from requirements.

Your reasoning and evidence:

### locate
Show one check that concerns state and one that concerns the interface.

Your reasoning and evidence:

### predict
What would your matrix show if the wrong visit were updated?

Your reasoning and evidence:

### compare
Compare a screen assertion with checking stored state; what can each miss?

Your reasoning and evidence:

### challenge
AI says 100% test coverage proves there are no defects. Explain the limit and propose a missing scenario.

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
