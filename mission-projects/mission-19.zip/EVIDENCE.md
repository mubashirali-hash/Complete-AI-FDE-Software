# Mission 19 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] A claim points to an inspected supporting passage or an action has an explicit authorized contract.
- [ ] Missing or outdated evidence does not become an invented current answer.
- [ ] Untrusted text cannot expand the feature's authority; the observed refusal is recorded.

## Understanding demonstrations

### explain
Explain similarity, retrieval, grounding and tool authority using your feature.

Your reasoning and evidence:

### locate
Find the source selection or tool-validation boundary in the actual system.

Your reasoning and evidence:

### predict
What if the nearest retrieved passage contradicts the current policy?

Your reasoning and evidence:

### compare
Compare keyword search, embeddings and direct structured queries for your information.

Your reasoning and evidence:

### challenge
AI says a document's instruction authorizes its tool call. Explain the trust error and test the boundary.

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
