# Mission 2 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] My request names an observable result and a constraint.
- [ ] The changed site satisfies both acceptance criteria I wrote before the change.
- [ ] The preserved behaviour still works and my before/after observations are recorded.

## Understanding demonstrations

### explain
Explain a constraint and an acceptance criterion from your change.

Your reasoning and evidence:

### locate
Show the changed part and the behaviour you preserved.

Your reasoning and evidence:

### predict
If the site changes language and labels become longer, what might break?

Your reasoning and evidence:

### compare
Compare a targeted improvement with a redesign. When would each fit?

Your reasoning and evidence:

### challenge
AI says prettier colours prove visitors find the hours faster. What evidence is missing?

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
