# Mission 6 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] Each important claim has an identifiable source or is labelled as an assumption/scenario.
- [ ] The map includes an actual constraint and a handoff between people or systems.
- [ ] The brief records a missing requirement, an unresolved question and how to investigate it.

## Understanding demonstrations

### explain
Explain why the requested feature may differ from the underlying problem.

Your reasoning and evidence:

### locate
Find a handoff and the source supporting it in your map.

Your reasoning and evidence:

### predict
What happens if access approval arrives after a technician is dispatched?

Your reasoning and evidence:

### compare
Compare observing a recent task with asking whether someone likes a proposed app.

Your reasoning and evidence:

### challenge
AI claims five fictional interviews prove demand. Explain what they establish and what evidence is still needed.

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
