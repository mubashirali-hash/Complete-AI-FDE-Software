# Mission 12 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] Saved visits remain after the intended process restart using the same storage configuration.
- [ ] Same-name customers remain distinguishable and visits connect to the correct identity.
- [ ] Missing information has an explicit meaning and an important value has recorded provenance.

## Understanding demonstrations

### explain
Explain memory, persistence, model, identifier, relationship and query.

Your reasoning and evidence:

### locate
Find the actual data store, its configuration and one query with AI's help.

Your reasoning and evidence:

### predict
What happens if a deployment uses a temporary disk or a different database URL?

Your reasoning and evidence:

### compare
Compare one flat record list with related customer and visit records.

Your reasoning and evidence:

### challenge
AI says every blank access value means refused access. What source evidence and data change are needed?

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
