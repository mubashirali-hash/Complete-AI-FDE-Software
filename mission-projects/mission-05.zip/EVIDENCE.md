# Mission 5 evidence

## Product evidence

Artifact / local location and opening instructions:
Starting state:
Action:
Expected result:
Actual observation:
Environment / revision / date:
Fixtures, reports, unrun checks and limits:

- [ ] Adding one valid record adds one correct card without copied layout work.
- [ ] No records produces an understandable empty state.
- [ ] Duplicate identities and the monetary rounding policy are handled as specified.

## Understanding demonstrations

### explain
Explain a collection, a loop and an abstraction using this catalogue.

Your reasoning and evidence:

### locate
Identify the records, the repeated work and the shared formatting rule.

Your reasoning and evidence:

### predict
What changes if one price changes? What if the shared rule changes?

Your reasoning and evidence:

### compare
Compare copied cards with a generated list, including the risk of a shared mistake.

Your reasoning and evidence:

### challenge
AI says 0.1 + 0.2 always equals exactly 0.3 in every runtime. How would you investigate and choose a money representation?

Your reasoning and evidence:

## Review

Reviewer or method:
Fresh scenario:
Prediction before result:
Observed reasoning and outcome:
Gaps and next practice:
Status: unreviewed / revisit / reviewer reports demonstrated

Field completeness is not concept mastery. AI remains available throughout.
