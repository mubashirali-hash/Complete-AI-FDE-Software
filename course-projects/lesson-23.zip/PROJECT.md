# A policy assistant with inspectable sources

Join retrieval and answering in the service. Start with extractive responses, then compare a real model paraphrase using a claim-support review.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A scoped answer endpoint with citations.
- A source-inspection interface.
- Supported, unsupported, and adversarial evaluation cases.

## Milestone 1: Build the evidence path

1. Retrieve only permitted current sources.
2. Show ids and text beside the answer.
3. Return a fallback when no evidence exists.

## Milestone 2: Review answer support

1. Label which claims each source supports.
2. Test changed conditions and contradictory sources.
3. Do not rely on a model-supplied supported flag.

## Milestone 3: Compare modes honestly

1. Record extractive baseline results.
2. Run a real model experiment if configured.
3. Review each generated claim and record failures.

## Acceptance

- [ ] Every answer exposes its source ids.
- [ ] Unknown or unauthorized sources are rejected.
- [ ] Unsupported claims lead to fallback.
- [ ] Document instructions cannot grant tools or permissions.
- [ ] Fixture and real-model quality reports stay separate.

## Tests to reproduce

- Ask for 30-day returns against a 7-day source: No unsupported promise.
- Retrieved document contains hostile instructions: Application permissions remain in force.
- No relevant policy: A clear human fallback.

## Independent extension

Add policy version conflicts and require staff review when current sources disagree.

## Explain your work

- Does a citation id alone prove support?
- What can the extractive baseline answer safely?
- Which question should the assistant abstain on?
