export default async function exercise(proposal,documents) {

function groundedAnswer(proposal,documents){const doc=documents.find(item=>item.id===proposal.sourceId);return doc&&proposal.quote===doc.text&&proposal.supported===true?{answer:doc.text,citations:[doc.id]}:{answer:"Ask Amina",citations:[]};}
return (groundedAnswer(proposal,documents));
}
