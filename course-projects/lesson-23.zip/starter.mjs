export default async function exercise(proposal,documents) {

function groundedAnswer(proposal,documents){return {answer:"Ask Amina",citations:[]};}
return (groundedAnswer(proposal,documents));
}
