# Give AI one carefully limited tool

Amina wants help preparing refunds. The assistant may propose a refund, but the service checks the order and a person approves the exact amount before money changes.

## A tool is an application capability

A tool call is a proposed function name and arguments. The application decides whether to execute it. Give the model only a small allowed set such as lookup_order and prepare_refund. Avoid arbitrary shell, SQL, or URL access.

Write an argument schema and limits for every tool. This lab accepts refund with positive integer orderId and amount, capped at 5000 cents. These are teaching limits, not a complete financial system.

## Validate and authorize on the server

Check the allowed tool name and exact argument fields. Then obtain identity from the session, verify shop and order ownership, and verify the refundable balance using authoritative data. Model-supplied ids are untrusted inputs.

A valid integer is not proof that an order exists or belongs to the caller. The browser exercise covers only tool shape and approval matching. The real project tests authorization, balance, replay, and an atomic database operation.

## Bind human approval to the proposal

Show the person the order, amount, currency, reason, and effect. Store approval on the server with the proposal digest, approver identity, expiry, and one-use state. Recheck permissions and current balance at execution.

Changing arguments invalidates approval. Expired, reused, or absent approvals must stop. Keep read-only lookup separate from writing a refund so the assistant can investigate without taking a financial action.

## Expect repetition and malicious text

A model may repeat a call or receive customer text telling it to ignore rules. Service permissions, approval, idempotency, and budgets remain in force regardless of that text. Tool output is also data, not trusted instructions.

Record safe audit events for proposal, approval, execution, and rejection. Reproduce a changed amount and a repeated approved call. The second execution must not create a second refund.

## Worked example

```javascript
function toolDecision(proposal,approved){if(proposal.name!=="refund")return "deny:tool";const a=proposal.args;if(!a||Object.keys(a).sort().join(",")!=="amount,orderId"||!Number.isInteger(a.orderId)||a.orderId<=0||!Number.isInteger(a.amount)||a.amount<=0||a.amount>5000)return "deny:args";if(!approved||approved.orderId!==a.orderId||approved.amount!==a.amount)return "wait:approval";return "execute";}
console.log(toolDecision({name:"refund",args:{orderId:3,amount:1200}},{orderId:3,amount:1000}));
```

wait:approval

- The tool name is checked first.
- The exact argument shape and amount are validated.
- An approval for different details cannot execute this proposal.

## Further reading

- [OpenAI function calling](https://developers.openai.com/api/docs/guides/function-calling)
