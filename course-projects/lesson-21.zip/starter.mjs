export default async function exercise(proposal,approved) {

function toolDecision(proposal,approved){return "execute";}
return (toolDecision(proposal,approved));
}
