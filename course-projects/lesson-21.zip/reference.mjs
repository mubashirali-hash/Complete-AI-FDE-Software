export default async function exercise(proposal,approved) {

function toolDecision(proposal,approved){if(proposal.name!=="refund")return "deny:tool";const a=proposal.args;if(!a||Object.keys(a).sort().join(",")!=="amount,orderId"||!Number.isInteger(a.orderId)||a.orderId<=0||!Number.isInteger(a.amount)||a.amount<=0||a.amount>5000)return "deny:args";if(!approved||approved.orderId!==a.orderId||approved.amount!==a.amount)return "wait:approval";return "execute";}
return (toolDecision(proposal,approved));
}
