# A read-only assistant and approved action

Add order lookup and a refund-proposal workflow to the service. Use simulated money in the learning database and enforce approval on the server.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- An allowed-tool registry and schemas.
- A server-stored approval flow.
- Permission, expiry, and replay tests.

## Milestone 1: Start with lookup

1. Validate an order id.
2. Apply session and shop permission checks.
3. Return only fields the assistant needs.

## Milestone 2: Prepare an action

1. Store a proposal with exact details.
2. Show those details to staff.
3. Store approval bound to the proposal and expiry.

## Milestone 3: Execute once

1. Recheck permission and balance.
2. Apply the simulated refund atomically.
3. Consume approval and reject replay.

## Acceptance

- [ ] Tools are explicitly listed.
- [ ] Record permissions run on the server.
- [ ] Approval refers to exact details.
- [ ] Expired or reused approval is rejected.
- [ ] A repeated request cannot duplicate the simulated refund.

## Tests to reproduce

- Change the approved amount: New approval is required.
- Request another shop’s order: Denied before data or action is returned.
- Replay an executed proposal: No second refund is created.

## Independent extension

Add a controlled-clock expiry test and a concurrent-execution test that proves only one operation commits.

## Explain your work

- Which checks are absent from the browser gate?
- Why must permissions be checked again at execution?
- What evidence proves replay protection?
