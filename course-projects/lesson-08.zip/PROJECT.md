# A customer message page

Create a standalone, semantic contact page with visible labels and a logical keyboard order. State that it is a practice form until a backend is connected.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- An HTML page with the contact form.
- A keyboard walkthrough.
- A list of browser and backend validation responsibilities.

## Milestone 1: Build the structure

1. Add main, a heading, and a form.
2. Use meaningful element types.

## Milestone 2: Connect the fields

1. Associate labels with inputs.
2. Add required rules and the action button.

## Milestone 3: Try another way to use it

1. Navigate with Tab and Enter.
2. Click each label to focus its field.
3. Check empty and valid input.

## Acceptance

- [ ] The purpose is clear from the heading.
- [ ] Both fields have visible connected labels.
- [ ] The action is a native button.
- [ ] Keyboard navigation and focus are usable.
- [ ] The page does not claim to send a real message yet.

## Tests to reproduce

- Tab through the page: Name, message, and action follow a logical order.
- Click Your name: The name input gains focus.
- Submit empty required fields: Browser validation asks for the missing values.

## Independent extension

Add a labelled email field and explain what the browser can check versus what the backend must still verify.

## Explain your work

- Why is a placeholder not enough?
- How did you check keyboard use?
- Why will the backend still need validation?
