# Build a page people can use

Amina wants customers to send a message without needing to understand her software. Give them a page with clear words, a name field, and a message field.

## HTML gives content a structure

HTML describes the meaning of a page. A heading introduces its subject. A main element contains the page’s primary content. A form groups related inputs and an action.

Use elements for their intended jobs. A button is already operable with a keyboard and exposes its role to assistive technology. A clickable div requires you to recreate those behaviours and is easy to get wrong.

## Connect a label to a field

A label tells a person what to enter. Give the input an id and set the label’s for attribute to the same id. Clicking the label will focus its input, and assistive technology can use the label as the field’s accessible name.

A placeholder is a hint inside an empty field. It disappears after typing and is not a replacement for a visible label. Choose clear names such as Your name and Your message rather than making the person guess.

## Use browser validation deliberately

The required attribute marks a field as necessary. The browser can check whether required fields contain a value. A textarea is useful for a message that may span several lines.

Browser validation helps people correct a form. It does not protect the backend: a request can be sent without this page. We will validate requests again at the service boundary in lesson 15.

## Try the page without a mouse

Use Tab to move between the name field, message field, and button. A visible focus outline helps you know where you are. Keep the order of elements logical and avoid positive tabindex values that create a surprising order.

This lesson builds the structure and checks the fields. It does not send a real customer message yet. Lesson 10 will add behaviour, and lesson 17 will connect an interface to a backend.

## Worked example

```html
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Amina's shop</title><style></style></head><body><main><h1>Contact Amina</h1><label for="customer">Your name</label><input id="customer" type="text"></main></body></html>
```

A heading, a visible name label, and a text field.

- main identifies the central content.
- The label’s for value matches the input id.
- The input supplies a native field with keyboard behaviour.

## Further reading

- [MDN forms](https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms)
