# Inspect the rendered result

- A clear main heading: A person needs to know what this page does.
- Fields belong to a form: A form groups the task and supports native submission behaviour.
- The name field has a connected label: A visible connected label works after the person starts typing.
- The message field has a connected label: A message needs an identified multi-line field.
- A native submit button: The action must be clear and keyboard operable.
- Empty required fields are rejected: Required fields need values.
- Filled fields pass browser validation: Validation should also allow intended success.

Check at 320px and 900px widths, with keyboard input. The course browser also executes these behaviour checks. Project acceptance requires the broader tests in PROJECT.md.
