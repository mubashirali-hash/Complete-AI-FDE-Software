# A team inbox filter

Give Amina a view of unfinished messages, with a choice of owner. Use fictional records and stable identifiers.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- An array of at least six message objects.
- A filter that returns matching ids.
- Examples covering empty and mixed queues.

## Milestone 1: Describe the data

1. Give each message an id, status, and owner.
2. Keep the records fictional.

## Milestone 2: Build the filter

1. Choose open status first.
2. Apply an optional owner condition.

## Milestone 3: Check the view

1. Record results for all owners and one named owner.
2. Confirm the original records are still intact.

## Acceptance

- [ ] Every selected message is open.
- [ ] A named owner excludes other owners.
- [ ] An empty owner selection includes all open work.
- [ ] Empty and all-closed inboxes return [].
- [ ] The original data and identifier order are preserved.

## Tests to reproduce

- Empty inbox: An empty list.
- Open messages owned by Amina and Bilal; select Amina: Only Amina’s ids.
- All messages closed: An empty list.

## Independent extension

Add a count of matching messages alongside the ids. Do not confuse a view filter with server-side permissions.

## Explain your work

- Why use an id rather than message text?
- What does the loop do for an empty array?
- What would a backend still need to check?
