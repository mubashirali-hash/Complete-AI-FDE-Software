# Lesson 3: Organise messages and work through a list

Start here:

1. Extract the ZIP into a new folder.
2. Read PROJECT.md to see the real project and its milestones.
3. Complete the browser exercise or edit the local starter. The supplied checker runs the final exercise contract.
4. node check.mjs.
5. Extend the warm-up into the actual project. Record normal, boundary, and failing results.

For lessons 15–30, download shop-workspace.zip from the course project page and follow its README. It supplies a real service and connected React page. Its offline mode requires no model key. Real provider experiments require your explicit configuration and budget.

Reference files are learning aids. An independent extension must be completed without copying its solution.
