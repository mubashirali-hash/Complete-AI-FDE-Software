# Organise messages and work through a list

A count alone cannot tell Amina who should answer each message. The shop needs a list of messages with an identifier, a status, and an owner.

## One message has several details

An object groups named details about one thing. A message might be { id: 1, status: "open", owner: "Amina" }. We use message.status to read its status, just as we use a label to find a value.

An identifier is a value used to recognise an item. Two messages can have the same text, so their text is a poor identifier. A stable id lets the interface update the intended message.

## An array holds a list

An array is an ordered list of values. Our inbox is an array of message objects. An empty inbox is [], a valid array with no items. It should produce an empty result rather than an error.

A new array can hold the identifiers we want to return. We start with let openIds = [] and add a matching id with openIds.push(message.id). The original inbox stays available for other operations.

## Repeat a rule for each item

A loop repeats instructions. for (const message of messages) visits each message in the list. Inside the loop, an if condition decides whether to include that message.

We want an open status and, when an owner is selected, the matching owner. The symbol && means both conditions must be true. The symbol || means either condition can be true. An empty owner selection means show all open messages.

## Choose data carefully

Filtering is useful for views, reports, and search. Amina can see her open work without deleting other messages. A filter should preserve the identifiers and ordering of the selected items.

A browser filter is not permission enforcement. Later, the backend will check who is allowed to read each record. For this exercise, all records are authorised fictional data and we are choosing the useful view.

## Worked example

```javascript
const messages = [{ id: 1, status: "open" }, { id: 2, status: "closed" }];
let openIds = [];
for (const message of messages) {
  if (message.status === "open") { openIds.push(message.id); }
}
console.log(openIds);
```

[1]

- The array contains two message objects.
- The loop visits both objects. === compares values without changing them.
- Only the open message contributes its id to the result.

## Further reading

- [JavaScript arrays](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Arrays)
