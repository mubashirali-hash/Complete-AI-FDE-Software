export default async function exercise(messages,owner) {

let openIds = [];
for (const message of messages) {
  if (message.status === "open" && (owner === "" || message.owner === owner)) { openIds.push(message.id); }
}
return (openIds);
}
