def exercise(price, quantity):
    
    def quote(price, quantity):
        return {}
    return (quote(price, quantity))
