# Move a familiar rule to Python

Amina needs the same correct price on her website and at the service that accepts orders. Use a familiar problem to learn Python before learning a server framework.

## Start with what you already know

Python has variables, conditions, lists, dictionaries, and functions. These are the same ideas you used in JavaScript. def introduces a function; return sends its result back. A dictionary such as {"total": 200} resembles a JavaScript object.

Python uses indentation to group statements. Put four spaces before the lines inside a function or if block. You do not put braces around those blocks. Read the program from the top and follow the values, rather than memorising punctuation.

## Use integer money

Keep amounts in cents. items = price * quantity computes the subtotal. // performs floor division: 505 // 10 is 50, so the discount stays a whole number. Write down the rounding policy before implementing it.

The conditional expression discount = items // 10 if quantity >= 5 else 0 chooses one of two values. You can also write a normal if block. Both forms must produce the same agreed prices.

## Keep a clear function boundary

This function accepts two numbers and returns a dictionary. It does not read a web page or connect to a database. That small boundary makes the pricing rule easy to test and reuse in a server.

Validate both inputs before multiplying. In Python, bool is related to int, so type(value) is int deliberately rejects True and False here. Raise ValueError when the caller breaks the contract. An API will later turn that into a useful response.

## Run it outside the browser

The exercise runs actual Python in a browser runtime. The downloadable kit also runs with Python on your computer. Use python --version, then python check.py in the extracted folder. Some systems use python3 instead.

A backend is a program that responds to requests and owns shared rules and data. Merely rewriting a function in Python does not create a server. In lesson 15 you will call this sort of function from a real HTTP endpoint.

## Worked example

```python
def quote(price, quantity):
    items = price * quantity
    discount = items // 10 if quantity >= 5 else 0
    return {"items": items, "total": items - discount}
print(quote(100, 5))
```

{"items": 500, "total": 450}

- def creates a reusable rule with two inputs.
- The subtotal and discount use whole cents.
- return gives the caller a structured result.

## Further reading

- [Python tutorial](https://docs.python.org/3/tutorial/)
