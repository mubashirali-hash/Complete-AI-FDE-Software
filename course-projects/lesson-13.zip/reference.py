def exercise(price, quantity):
    
    def quote(price, quantity):
        if type(price) is not int or type(quantity) is not int or price < 0 or quantity < 0:
            raise ValueError("Use non-negative whole numbers")
        items = price * quantity
        discount = items // 10 if quantity >= 5 else 0
        return {"items": items, "total": items - discount}
    return (quote(price, quantity))
