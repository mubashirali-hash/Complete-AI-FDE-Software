# The same quote in two languages

Run the JavaScript and Python pricing rules against an agreed set of order examples. Explain any intentional difference before changing code.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- Both implementations.
- A shared table of expected quotes.
- A README with both commands.

## Milestone 1: Prepare the contract

1. Write down inputs, outputs, rounding, and rejection rules.
2. Choose ordinary, threshold, and invalid examples.

## Milestone 2: Translate and run

1. Run the Python kit.
2. Implement the same rule in JavaScript.
3. Compare each result with the agreed table.

## Milestone 3: Explain and extend

1. Add shipping as a separate input.
2. Document how each language reports an invalid input.
3. Have another person run both commands.

## Acceptance

- [ ] Money stays in whole cents.
- [ ] Both languages match the agreed valid quotes.
- [ ] Invalid inputs are rejected.
- [ ] Discount rounding is documented.
- [ ] Both commands work from the README.

## Tests to reproduce

- Five items at 101 cents: 505 subtotal and 455 before shipping.
- Negative or boolean quantity: A clear rejection.
- Shipping applied: The documented order of calculations is followed.

## Independent extension

Add a maximum order size and test its exact boundary in both languages.

## Explain your work

- Which ideas transferred directly?
- Where did indentation change how you read the program?
- Why should the API call this rule rather than copy it?
