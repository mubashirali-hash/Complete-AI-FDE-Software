import json
from starter import exercise
cases=json.loads("[{\"id\":\"ordinary\",\"label\":\"Two items\",\"args\":[100,2],\"expected\":{\"items\":200,\"total\":200},\"why\":\"The common case remains unchanged.\"},{\"id\":\"zero\",\"label\":\"An empty order\",\"args\":[100,0],\"expected\":{\"items\":0,\"total\":0},\"why\":\"Zero is an allowed boundary.\"},{\"id\":\"bulk\",\"label\":\"The first discounted quantity\",\"args\":[100,5],\"expected\":{\"items\":500,\"total\":450},\"why\":\"The threshold is inclusive.\"},{\"id\":\"rounding\",\"label\":\"A whole-cent discount\",\"args\":[101,5],\"expected\":{\"items\":505,\"total\":455},\"why\":\"Floor rounding prevents fractional cents.\"},{\"id\":\"negative\",\"label\":\"Negative quantity\",\"args\":[100,-1],\"expected\":null,\"why\":\"Bad input must not become a price.\",\"error\":\"ValueError\"},{\"id\":\"fraction\",\"label\":\"Fractional quantity\",\"args\":[100,1.5],\"expected\":null,\"why\":\"The shop sells whole units.\",\"error\":\"ValueError\"},{\"id\":\"boolean\",\"label\":\"A boolean quantity\",\"args\":[100,true],\"expected\":null,\"why\":\"Python booleans must not silently become quantities.\",\"error\":\"ValueError\"}]")
for case in cases:
    try:
        actual=exercise(*case.get('args',[]))
    except Exception as error:
        assert case.get('error')==type(error).__name__, (case['id'],str(error))
    else:
        assert not case.get('error') and json.dumps(actual,sort_keys=True)==json.dumps(case.get('expected'),sort_keys=True), (case['id'],actual,case.get('expected'))
    print('PASS',case['label'])
print('Exercise checks passed. Complete PROJECT.md separately.')
