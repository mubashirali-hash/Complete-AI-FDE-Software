# A hardened release and rollback

Perform a threat review, data migration rehearsal, and rollback of the real capstone with safe data. Preserve the evidence for a reviewer.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A boundary-specific threat and test matrix.
- A migration/backup/restore report.
- A versioned release and recovery runbook.

## Milestone 1: Test the boundaries

1. Attempt cross-shop and cross-customer requests.
2. Test approval change, expiry, and replay.
3. Inspect rendering, provider validation, and safe logs.

## Milestone 2: Rehearse data change

1. Back up and verify the restored copy.
2. Migrate a copy and compare rows and relationships.
3. Record whether rollback requires data restore.

## Milestone 3: Release and recover

1. Build a known commit with production configuration documented.
2. Run health and main-flow smoke checks.
3. Restore after a deliberate failure and repeat the checks.

## Acceptance

- [ ] Denied operations cannot change protected data.
- [ ] Secrets stay out of client code and logs.
- [ ] Migration preserves intended records and constraints.
- [ ] Backup restore is tested.
- [ ] Rollback produces a usable main flow.

## Tests to reproduce

- Another shop requests a source: No source content leaks.
- Migration sees invalid status: It stops with no silent data rewrite.
- A release fails its smoke test: The verified earlier version and intended data are restored.

## Independent extension

Arrange an independent security review and address one reproduced finding with a focused regression test.

## Explain your work

- Which test checked the real boundary?
- What would rolling back code fail to restore?
- What evidence supports the release decision?
