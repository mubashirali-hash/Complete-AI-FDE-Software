# Harden the capstone and rehearse recovery

Before staff rely on the capstone, Amina asks what happens if a deployment fails or a customer tries to access another shop. Prove those answers with tests and a recovery rehearsal.

## Review threats at each boundary

List assets, callers, trust boundaries, and likely failures. Test unauthorized reads/writes, changed approval, replay, unsafe HTML rendering, malformed model output, document injection, and private logging. Include provider egress and spending limits.

The lab is a pure-data migration exercise. It does not certify security. The real project requires direct requests that attempt the denied operations and inspection of actual database and log outcomes.

## Plan a migration before executing it

Describe the old schema, new schema, preserved fields, constraints, and invalid-data policy. Run a dry run on a copy. Verify row counts, ids, relationships, and representative records afterward.

Keep a verified backup and test restore. A rollback may require both application version and data restore. Never assume reversing a code commit reverses a database migration or an external operation.

## Harden the deployment

Serve over HTTPS with production cookie settings. Restrict accepted hosts and origins, set resource and request limits, and keep keys in server configuration. Pin dependencies and inspect the frontend bundle for accidental private configuration.

Use health and smoke checks from the release lesson. Configure log access and retention. Record who can deploy, approve risky actions, rotate keys, and recover data. The local learning accounts and localhost settings are not production credentials.

## Rehearse and retain evidence

Deploy a known version into a rehearsal environment with safe data. Attempt the cross-shop tests and a deliberate failed change. Restore the verified version and data, then repeat the main flow.

Publish a concise release record with commit, configuration mode, migration result, evaluation version, known limits, and recovery evidence. If a required check fails, fix it or keep the release blocked with a clear owner.

## Worked example

```javascript
function migrate(rows){const ids=new Set();return rows.map(row=>{if(!Number.isInteger(row.id)||row.id<=0||ids.has(row.id))throw new RangeError("Invalid or duplicate id");ids.add(row.id);const status=row.status??"open";if(!["open","closed"].includes(status))throw new RangeError("Invalid status");return {...row,status};});}
console.log(migrate([{id:1,text:"Hello"}]));
```

[{"id":1,"text":"Hello","status":"open"}]

- A new object preserves the old fields.
- The missing status gets the agreed default.
- Invalid status or identifiers stop rather than silently repair records.

## Further reading

- [OWASP application security verification](https://owasp.org/www-project-application-security-verification-standard/)
- [SQLite backup guidance](https://www.sqlite.org/backup.html)
