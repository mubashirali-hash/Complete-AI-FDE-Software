export default async function exercise(rows) {
const before=JSON.stringify(rows);
function migrate(rows){const ids=new Set();return rows.map(row=>{if(!Number.isInteger(row.id)||row.id<=0||ids.has(row.id))throw new RangeError("Invalid or duplicate id");ids.add(row.id);const status=row.status??"open";if(!["open","closed"].includes(status))throw new RangeError("Invalid status");return {...row,status};});}
return (({rows:migrate(rows),unchanged:JSON.stringify(rows)===before}));
}
