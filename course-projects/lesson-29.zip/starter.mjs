export default async function exercise(rows) {
const before=JSON.stringify(rows);
function migrate(rows){return rows;}
return (({rows:migrate(rows),unchanged:JSON.stringify(rows)===before}));
}
