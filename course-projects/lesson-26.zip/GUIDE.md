# Find a failure without exposing private data

Amina reports that some requests fail. You need enough evidence to find the fault, but logging every message, password, or token creates another problem.

## Observe outcomes and boundaries

Logs are records of events. Metrics summarize counts or distributions. A trace connects events from the same operation. Use a generated request id to connect frontend reports, server events, and provider outcomes.

Record safe event names, status, elapsed time, error code, and version. These can reveal where latency or failure occurs. A trace without private message content can still show that a provider timed out after retrieval succeeded.

## Use an allowed list of fields

Select fields to log instead of copying entire request or exception objects. Passwords, API keys, session tokens, customer text, and unrestricted tool output should not enter routine logs. Even ids can be personal data, so collect only what the investigation needs.

The lab returns a small allowed-field record. It is not a complete anonymizer: free-form request ids can themselves contain private text. The project generates ids on the service and uses a fixed event vocabulary, retention policy, and restricted access.

## Reproduce before repairing

Record the reported operation, expected result, actual result, version, and safe request id. Reproduce using disposable data. Narrow the boundary: interface, API validation, data query, retrieval, provider, or tool execution.

Make a focused repair and add a regression case for the original trigger. Do not clear errors by converting failures to success. Verify the main operation and inspect whether the repair changes other important outcomes.

## Recover and communicate clearly

An incident report states impact, timeline, cause supported by evidence, repair, verification, and prevention. If cause is uncertain, state what the evidence does and does not show.

A temporary fallback may keep the shop working while the model is unavailable. Distinguish recovery from permanent repair. Rehearse deletion and retention of logs, and verify that a secret sent in a test never appears in captured events.

## Worked example

```javascript
function safeLog(record){const status=["ok","failed","denied"].includes(record.status)?record.status:"unknown";const duration=Number.isFinite(record.duration)&&record.duration>=0?record.duration:0;const code=typeof record.code==="string"&&/^[A-Z_]{1,40}$/.test(record.code)?record.code:"UNKNOWN";return {requestId:String(record.requestId||"missing").slice(0,80),event:["request","tool","provider"].includes(record.event)?record.event:"unknown",status,duration,code};}
console.log(safeLog({requestId:"r1",event:"provider",status:"failed",duration:1200,code:"TIMEOUT",apiKey:"private"}));
```

{"requestId":"r1","event":"provider","status":"failed","duration":1200,"code":"TIMEOUT"}

- Only selected fields enter the output.
- Status, duration, and code have explicit contracts.
- The apiKey field is never copied.

## Further reading

- [OWASP logging guidance](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html)
