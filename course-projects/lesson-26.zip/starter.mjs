export default async function exercise(record) {

function safeLog(record){return record;}
return (safeLog(record));
}
