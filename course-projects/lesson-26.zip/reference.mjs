export default async function exercise(record) {

function safeLog(record){const status=["ok","failed","denied"].includes(record.status)?record.status:"unknown";const duration=Number.isFinite(record.duration)&&record.duration>=0?record.duration:0;const code=typeof record.code==="string"&&/^[A-Z_]{1,40}$/.test(record.code)?record.code:"UNKNOWN";return {requestId:String(record.requestId||"missing").slice(0,80),event:["request","tool","provider"].includes(record.event)?record.event:"unknown",status,duration,code};}
return (safeLog(record));
}
