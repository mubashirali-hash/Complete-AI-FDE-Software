# A reproducible timeout incident

Inject a provider timeout in the service workspace, follow its safe request trace, repair recovery behaviour, and add a regression test.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A safe structured event report.
- An incident reproduction and repair.
- Retention and private-field test evidence.

## Milestone 1: Instrument boundaries

1. Generate the request id on the server.
2. Use fixed event and error codes.
3. Record duration and version without customer text.

## Milestone 2: Reproduce and repair

1. Use a disposable failing provider adapter.
2. Locate the failing boundary from events.
3. Return an honest fallback and retain the user draft.

## Milestone 3: Verify and document

1. Add the timeout as a regression.
2. Search captured logs for a planted test secret.
3. Write impact, supported cause, recovery, and prevention.

## Acceptance

- [ ] Events connect using a server-generated id.
- [ ] Private content and credentials are excluded.
- [ ] Timeouts are reported accurately.
- [ ] The original failing operation has a regression.
- [ ] Retention and access rules are documented.

## Tests to reproduce

- Planted secret in request: Absent from captured logs.
- Provider timeout: A controlled fallback and diagnostic code.
- Recovery run: The original flow succeeds without hiding errors.

## Independent extension

Add a latency dashboard and alert threshold, then test its behaviour with synthetic slow requests.

## Explain your work

- Which evidence located the fault?
- What data did you deliberately avoid collecting?
- What separates recovery from the root-cause repair?
