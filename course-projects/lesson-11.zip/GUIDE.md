# Load orders and handle request failures

The inbox needs to load orders from a service. The network can be slow, a response can be an error, and a successful status can still contain unexpected data.

## Programs can ask another program

An HTTP request asks a server to do something. A GET request commonly reads information. The server returns a status, headers, and a body. JSON is one common format for the body.

A URL identifies the destination. An endpoint is a particular operation exposed by the service, such as GET /orders. Agree on the response shape: our practice order list contains objects with an id and a totalCents value.

## A request finishes later

An asynchronous operation returns a promise for a future result. async marks a function that can wait for promises. await waits for an operation inside that function without pretending its result is already available.

A page can show Loading while a request is in progress. After it finishes, show the data, an empty state, or an error. Keep these states distinct so an empty order list is not mistaken for a broken service.

## Check status and data shape

fetch does not automatically reject every HTTP error status. Check response.ok before reading the body. Then await response.json() and validate the data shape before handing it to the interface.

A response with status 200 and a JSON object is still wrong if the contract requires an array. A row with a negative total or missing identifier also breaks the contract. Use the validation habits you already practised with saved baskets.

## Recover without hiding the problem

Network failures and JSON parsing errors can throw. Catch them and return a useful error result. Avoid an infinite retry loop: give the person a deliberate Try again action and make operations safe to repeat.

The exercise injects a prepared request function to test these outcomes reliably. It does not call a live service. The project connects the same adapter to real fetch and checks browser network behaviour against your local backend.

## Worked example

```javascript
async function loadExample() {
  const response = { ok: true, json: async () => [{ id: 1, totalCents: 600 }] };
  const orders = await response.json();
  return orders.length;
}
return loadExample().then(count => console.log(count));
```

1

- The response here is a prepared example, not a live request.
- await waits for the promise returned by json().
- The function returns the count after the data is available.

## Further reading

- [MDN fetch](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch)
