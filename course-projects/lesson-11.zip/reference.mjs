export default async function exercise(scenario) {
const request = async () => {
  if (scenario === "network") throw new Error("Connection failed");
  if (scenario === "bad-json") return { ok: true, json: async () => { throw new Error("Bad JSON"); } };
  return { ok: scenario !== "http", json: async () => scenario === "shape" ? {} : scenario === "bad-row" ? [{id:1,totalCents:-2}] : scenario === "empty" ? [] : [{id:1,totalCents:600}] };
};
async function loadOrders(request) {
  try {
    const response = await request();
    if (!response.ok) return { ok: false, error: "http" };
    const orders = await response.json();
    if (!Array.isArray(orders) || !orders.every(order => order && Number.isInteger(order.id) && Number.isInteger(order.totalCents) && order.totalCents >= 0)) return { ok: false, error: "shape" };
    return { ok: true, orders };
  } catch { return { ok: false, error: "network" }; }
}
return (loadOrders(request));
}
