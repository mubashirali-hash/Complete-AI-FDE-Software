# A reliable order-loading screen

Build a loading adapter and a view with loading, empty, success, and error states. Begin with prepared requests; connect it to your real service in lesson 17.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- The adapter and its result contract.
- A view for each request state.
- A network inspection record after real integration.

## Milestone 1: Agree on the result

1. Describe the order response shape.
2. Keep an empty list distinct from failure.

## Milestone 2: Handle failures

1. Check HTTP status and body shape.
2. Catch request and parsing errors.

## Milestone 3: Integrate and observe

1. Give the interface a deliberate retry action.
2. After backend setup, inspect a real request and response in the browser.

## Acceptance

- [ ] Valid records load correctly.
- [ ] Empty data shows an empty state.
- [ ] HTTP, connection, and shape failures are handled.
- [ ] Loading always ends in a useful state.
- [ ] Fixture checks are distinguished from a real request check.

## Tests to reproduce

- Valid prepared response: Success with the supplied order.
- Failed connection: An error result with a retry action.
- A real service returns an invalid body: The interface rejects its shape.

## Independent extension

Add a timeout using AbortController when connecting to fetch. Keep retries bounded and cancellation visible.

## Explain your work

- Why does response.ok matter?
- How is empty data different from failure?
- What evidence proves you made a real network request?
