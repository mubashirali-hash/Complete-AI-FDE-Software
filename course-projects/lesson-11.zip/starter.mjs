export default async function exercise(scenario) {
const request = async () => {
  if (scenario === "network") throw new Error("Connection failed");
  if (scenario === "bad-json") return { ok: true, json: async () => { throw new Error("Bad JSON"); } };
  return { ok: scenario !== "http", json: async () => scenario === "shape" ? {} : scenario === "bad-row" ? [{id:1,totalCents:-2}] : scenario === "empty" ? [] : [{id:1,totalCents:600}] };
};
async function loadOrders(request) { return { ok: true, orders: [] }; }
return (loadOrders(request));
}
