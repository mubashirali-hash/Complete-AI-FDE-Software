# A working shop inbox

Build an interface that accepts messages, validates them, and displays an accurate list and count. This is a local practice inbox; backend integration comes later.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A functional form and inbox.
- A clear render function and state array.
- An interaction test record.

## Milestone 1: Display the state

1. Render a list and matching count.
2. Use textContent for message bodies.

## Milestone 2: Handle an action

1. Use a form submission listener.
2. Add a valid message and redraw the view.

## Milestone 3: Check repeated and failed actions

1. Try two messages, a blank message, and HTML-looking text.
2. Submit with a keyboard.
3. Confirm no accidental page navigation.

## Acceptance

- [ ] The count matches the list.
- [ ] A valid submission adds one message.
- [ ] A blank submission preserves state and shows help.
- [ ] Customer text is rendered safely.
- [ ] Repeated actions and keyboard submission work.

## Tests to reproduce

- Submit a valid message: One new record appears and the count increases.
- Submit spaces: No new record; a helpful message appears.
- Submit HTML-looking text: Literal text appears without creating an element.

## Independent extension

Add an Answer button for each stable id. Update the state first, then render the new view.

## Explain your work

- What is the source of truth?
- Why prevent the default submission?
- Why use textContent for customer content?
