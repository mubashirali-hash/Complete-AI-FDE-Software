# Connect buttons, events, and state

Amina’s page has fields and buttons, but they do not do anything yet. Connect the form to a list of messages and show what actually happened.

## The DOM is the page as objects

The browser turns HTML into a document object model, or DOM. JavaScript can find an element with document.getElementById and change its textContent. This connects the data in a program to the visible page.

Use textContent when displaying a customer’s message. It treats the content as text. Setting innerHTML with untrusted text can create elements or scripts the person never intended to author for your page.

## An event tells you something happened

Submitting a form or pressing a button creates an event. addEventListener connects an event type to a function. The function can read fields, validate input, change state, and show a result.

Call event.preventDefault() when your JavaScript handles the form locally. Otherwise the browser’s default submission can navigate away from the page. Keep the native form and button so keyboard users can trigger the same behaviour.

## Keep state and rendering separate

State is the data the application is keeping track of now. Our messages array is state. A render function reads that array and draws the count and list. It does not invent a second, conflicting source of truth.

After adding a record to messages, call render again. Clear the list before recreating its items so old records do not appear twice. A stable identifier will help when later features answer or remove a particular message.

## Handle a failed action clearly

Trim whitespace before deciding whether a message is empty. If it is empty, show Write a message first and leave the state unchanged. If it is valid, add it, clear the field, and show Added.

Test the sequence a person actually uses, including keyboard submission and a second message. Also try text that looks like HTML. It should appear as text in the list, without being interpreted as a new element.

## Worked example

```html
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Amina's shop</title><style></style></head><body><button id="add">Add 1 message</button><output id="count">10</output><script>let messages=10; document.getElementById("add").addEventListener("click",()=>{messages+=1;document.getElementById("count").textContent=messages;});</script></body></html>
```

Pressing Add 1 message changes the count from 10 to 11.

- The program starts with state equal to 10.
- The listener responds when the button is activated.
- It changes the state and updates the output element.

## Further reading

- [MDN events](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Events)
