# Inspect the rendered result

- The initial count matches the state: The screen should be a view of the actual state.
- The initial message is visible: Rendering must show the data, not only a number.
- A submitted message updates the inbox without navigation: The event must update state and the screen while preserving the page.
- Blank input leaves the state unchanged: A rejected action should explain the problem without changing the data.
- HTML-looking customer text remains text: Customer content must not become executable page markup.

Check at 320px and 900px widths, with keyboard input. The course browser also executes these behaviour checks. Project acceptance requires the broader tests in PROJECT.md.
