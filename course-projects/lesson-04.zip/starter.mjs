export default async function exercise(priceCents,quantity,shippingCents) {

function quote(priceCents, quantity, shippingCents) {
  return { items: 0, discount: 0, total: 0 };
}
return (quote(priceCents, quantity, shippingCents));
}
