# Use functions to make reliable quotes

Different staff members are quoting different prices for the same order. Amina wants one clear calculation everyone can use.

## Give a group of instructions a name

A function groups instructions so they can be reused. A quote function receives a price, quantity, and shipping cost, then returns an answer. Calling the function runs its instructions for the inputs you supply.

The values listed in the function definition are parameters. The values supplied in a call are arguments. A return instruction sends a result back to the caller. These words describe the inputs and output you already used in earlier lessons.

## Agree on a contract

A contract states what inputs a function accepts and what it returns. Our quote accepts a whole-number price in cents, a positive whole-number quantity, and a non-negative shipping cost. It returns items, discount, and total.

A function should reject inputs outside that contract rather than produce a plausible-looking price. We use throw new RangeError to report unacceptable numbers. The caller can catch that error and explain it to the person using the app.

## Keep money exact

Use integer cents for this exercise. A price of 200 cents is two units of currency with one hundred cents per unit. Adding and multiplying whole-number cents avoids common decimal-fraction surprises.

The shop’s fictional rule is a 10% item discount for quantities of five or more. Round the discount down to a whole cent using Math.floor(items / 10). Add shipping after subtracting the discount. Real products must agree on their currency and rounding policy.

## Separate the rule from the screen

The quote function should not read a text box or draw a button. Its job is calculation and validation. An interface can collect input and display the returned result. A backend can reuse the same contract while obtaining prices from an authoritative catalogue.

A small function is easier to test because we can call it with several inputs without opening the whole application. Good boundaries also make change safer: a new screen need not invent a new pricing rule.

## Worked example

```javascript
function itemCost(priceCents, quantity) {
  return priceCents * quantity;
}
console.log(itemCost(200, 3));
```

600

- The function names its two inputs.
- return sends their product back to the caller.
- The call supplies 200 and 3. Another call can reuse the instructions with different numbers.

## Further reading

- [JavaScript functions](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Functions)
