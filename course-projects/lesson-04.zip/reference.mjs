export default async function exercise(priceCents,quantity,shippingCents) {

function quote(priceCents, quantity, shippingCents) {
  if (![priceCents, quantity, shippingCents].every(Number.isInteger) || priceCents < 0 || quantity < 1 || shippingCents < 0) { throw new RangeError("Invalid quote input"); }
  const items = priceCents * quantity;
  const discount = quantity >= 5 ? Math.floor(items / 10) : 0;
  return { items, discount, total: items - discount + shippingCents };
}
return (quote(priceCents, quantity, shippingCents));
}
