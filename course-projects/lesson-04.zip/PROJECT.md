# A reliable quote desk

Build a reusable quote function and a small catalogue of examples. Another developer should be able to call it without reading the implementation.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A documented quote contract.
- The quote function and tests.
- An explanation of currency units and rounding.

## Milestone 1: Write the contract

1. Name the units for every price.
2. List valid input ranges and output fields.

## Milestone 2: Implement the rules

1. Calculate items and shipping.
2. Add validation and the quantity discount.

## Milestone 3: Review the boundaries

1. Test quantities of four and five.
2. Test a fractional-cent discount and rejected inputs.

## Acceptance

- [ ] One function owns the calculation.
- [ ] All money values use integer cents.
- [ ] Invalid inputs raise RangeError.
- [ ] The discount boundary and rounding policy are tested.
- [ ] A caller can understand every output field.

## Tests to reproduce

- Four items: No discount.
- Five items at 101 cents: 50 cents discount.
- Zero quantity: Rejected.

## Independent extension

Add a second delivery option using a separate function. Keep catalogue prices controlled by the shop.

## Explain your work

- Why separate calculation from the interface?
- What does the contract protect?
- Which rounding decision did you make explicit?
