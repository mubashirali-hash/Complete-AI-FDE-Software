# An evaluation-driven change

Prepare a dataset, compare two assistant versions, and write a release recommendation that includes the worst failures.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A reviewed development and held-out dataset.
- A reproducible evaluation command.
- A version comparison and release recommendation.

## Milestone 1: Label examples

1. Collect at least 30 varied questions.
2. Record expected outcome and evidence.
3. Separate tuning and held-out sets.

## Milestone 2: Run both versions

1. Keep inputs identical for comparison.
2. Record quality, coverage, latency, and usage.
3. Distinguish fixture from real-model runs.

## Milestone 3: Decide from evidence

1. Inspect changed and severe failures.
2. Add a reproduced incident as a regression.
3. Recommend release, revision, or further evidence.

## Acceptance

- [ ] Labels include reasons and evidence.
- [ ] The held-out set stays separate from tuning.
- [ ] Coverage and precision are both reported.
- [ ] Severe failures are listed individually.
- [ ] The report identifies every version and execution mode.

## Tests to reproduce

- Always escalate baseline: Zero coverage is visible.
- New version invents one costly promise: The failure is visible despite a good average.
- Empty dataset: The report does not claim validated quality.

## Independent extension

Add confidence intervals or repeated-run variability with a clear explanation of their assumptions.

## Explain your work

- What does accuracy hide here?
- Which failure outweighs a small average improvement?
- How would you avoid tuning to the held-out set?
