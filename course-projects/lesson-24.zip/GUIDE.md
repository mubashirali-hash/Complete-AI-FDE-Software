# Measure AI quality before changing it

A new prompt answers more messages, but Amina suspects it makes more wrong promises. Measure correctness and coverage together before deciding that it is better.

## Create a labelled dataset

An evaluation dataset contains representative inputs and agreed expected outcomes. Include normal, ambiguous, malformed, missing-source, cross-shop, and adversarial cases. Keep input, label, reason, and source evidence together.

Separate a development set used for tuning from a held-out set used for comparison. Repeatedly changing a prompt after reading every held-out failure turns that set into development data. Collect new cases and document how labels were reviewed.

## Measure several outcomes

Accuracy measures all exactly correct outcomes, including a correct human fallback. Coverage measures the fraction answered without human fallback. Answer precision measures correct automated answers divided by all automated answers.

An assistant that always says human can have zero coverage. An assistant that answers everything can have poor precision. Decide an acceptable tradeoff using the costs of false answers and review workload; do not choose the highest-looking number alone.

## Review failures, not only averages

Record each failure’s category and severity. A wrong promise involving money may require a release stop even if the average accuracy is high. Treat permission violations and secret exposure as failures independently of language quality.

Keep prompt, model, schema, retrieval index, and dataset versions. Save latency, actual usage, refusals, and timeouts. Fixture tests prove deterministic control behaviour; real-model runs supply separate quality evidence.

## Make changes comparable

Run old and new versions on the same labelled inputs and inspect the changed outcomes. Repeat real runs when randomness or provider behaviour matters. Note sample size and variability rather than claiming certainty from a tiny set.

Add each reproduced incident as a regression case. Keep the regression focused on the failure while still running the broader suite. Require human review of important release decisions instead of equating one aggregate threshold with safety.

## Worked example

```javascript
function score(rows){const total=rows.length;const correct=rows.filter(row=>row.actual===row.expected).length;const answered=rows.filter(row=>row.actual!=="human");const answerCorrect=answered.filter(row=>row.actual===row.expected).length;return {total,correct,accuracy:total?correct/total:0,coverage:total?answered.length/total:0,answerPrecision:answered.length?answerCorrect/answered.length:0};}
console.log(score([{expected:"order",actual:"order"},{expected:"refund",actual:"human"}]));
```

{"total":2,"correct":1,"accuracy":0.5,"coverage":0.5,"answerPrecision":1}

- There is one exact match among two total cases.
- Only one case received an automated answer.
- That one automated answer was correct, so its precision is 1.

## Further reading

- [OpenAI evaluation practices](https://developers.openai.com/api/docs/guides/evaluation-best-practices)
