export default async function exercise(rows) {

function score(rows){const total=rows.length;const correct=rows.filter(row=>row.actual===row.expected).length;const answered=rows.filter(row=>row.actual!=="human");const answerCorrect=answered.filter(row=>row.actual===row.expected).length;return {total,correct,accuracy:total?correct/total:0,coverage:total?answered.length/total:0,answerPrecision:answered.length?answerCorrect/answered.length:0};}
return (score(rows));
}
