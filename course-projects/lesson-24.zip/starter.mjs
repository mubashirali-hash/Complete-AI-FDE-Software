export default async function exercise(rows) {

function score(rows){return {};}
return (score(rows));
}
