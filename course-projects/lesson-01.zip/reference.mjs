export default async function exercise(current,incoming,answered) {

let remaining = current + incoming - answered;
return (remaining);
}
