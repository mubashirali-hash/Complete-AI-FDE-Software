export default async function exercise(current,incoming,answered) {

let remaining = current;
return (remaining);
}
