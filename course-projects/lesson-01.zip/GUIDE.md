# Count messages and show the result

Amina has 10 messages. Two new messages arrive, and she answers three. Help her keep the remaining count correct.

## A name for a changing number

The shop needs a number it can update. A variable is a name a program uses to keep track of a value. In our example, messages is the name and 10 is its first value. When another message arrives, the name stays the same and the number becomes 11.

A familiar example is the score in a game. The score changes as you play. A program needs to remember the current score, rather than guess it from the screen. A message count works in the same way.

## Where the numbers come from

Input means information given to a program. We give our counter three inputs: the current count, the number of new messages, and the number Amina answered. Output means the result the program gives back. Here, the output is the remaining count.

For this first exercise, the lesson supplies those inputs. You only change the calculation. Later, an interface will collect inputs from a person, and a backend will load them from stored records. The calculation will still have the same job.

## Read the calculation in order

Start with 10. Add 2 to get 12. Subtract 3 to get 9. In JavaScript, + adds numbers and - subtracts them. We write current + incoming - answered to describe that process.

The equals sign in let remaining = current + incoming - answered stores the calculated result under the name remaining. Read the right side first, calculate its value, then connect that value to the name on the left. You do not need to memorise every symbol today.

## Check the result yourself

Before running the code, work out one example on paper. After running it, compare the output with your expected number. If you expected 9 and got 12, look for the instruction that subtracts answered messages.

Choose a second example too. If there are zero messages and zero new messages, the result should be zero. A working program should handle quiet days as well as busy days. The checks in the exercise try both situations.

## Worked example

```javascript
let current = 10;
let incoming = 2;
let answered = 3;
let remaining = current + incoming - answered;
console.log(remaining);
```

9

- The first three lines give the program its input numbers.
- The fourth line calculates 10 + 2 - 3 and keeps 9 under the name remaining.
- console.log displays the value so you can check it. It does not save the number permanently.

## Further reading

- [JavaScript variables](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Variables)
