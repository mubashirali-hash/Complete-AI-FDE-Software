# A small message desk

Make a calculation Amina can use to check the work left at the end of a shift. Use your completed exercise as the first version.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A calculation using all three named inputs.
- Two new examples with predicted and observed results.
- A short explanation of what the output means.

## Milestone 1: Build the calculation

1. Use current, incoming, and answered.
2. Calculate remaining in one readable line.

## Milestone 2: Try another shift

1. Predict the result for 8 current, 5 incoming, and 4 answered.
2. Run that case and compare it with your prediction.

## Milestone 3: Explain the work

1. Name the three inputs and the output.
2. Describe what would happen if the subtraction were missing.

## Acceptance

- [ ] New arrivals increase the count.
- [ ] Answered messages decrease it.
- [ ] A quiet shift returns zero.
- [ ] Your new example has a recorded expected and actual result.
- [ ] You can explain the calculation without reading the answer.

## Tests to reproduce

- 8 current, 5 incoming, 4 answered: 9 messages remain.
- 0 current, 0 incoming, 0 answered: 0 messages remain.
- 3 current, 0 incoming, 3 answered: 0 messages remain.

## Independent extension

Try a shift where Amina answers more messages than exist. Write down the problem you notice. Lesson 2 adds a rule to reject that input.

## Explain your work

- What information does the program need?
- What does remaining represent?
- What did your extra example help you check?
