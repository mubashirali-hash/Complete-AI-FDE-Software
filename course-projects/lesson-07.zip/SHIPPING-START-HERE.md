# The real Git project

The readiness planner is only the browser warm-up. Run `node project-check-shipping.mjs`: it deliberately fails against project-shipping.mjs. Reproduce the failure, initialize Git, commit the starting version, create feature/shipping-fix, and repair that file using lesson 6. Run the command again, inspect git diff, and make a focused commit. The reference file is a learning aid; explain your repair before using it. Record your branch, commit, check output, and clean-folder setup test.
