export default async function exercise(files,testsPass,branch) {

function assessChange(files, testsPass, branch) { return "ready"; }
return (assessChange(files, testsPass, branch));
}
