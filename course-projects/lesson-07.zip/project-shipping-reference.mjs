export default function decideShipment(amount, payment) {
  if (!Number.isInteger(amount) || amount < 0) throw new RangeError("Invalid amount");
  return payment === "paid" && amount >= 5000 ? "ship" : "hold";
}
