export default async function exercise(files,testsPass,branch) {

function assessChange(files, testsPass, branch) {
  if (!testsPass) return "stop:tests";
  if (branch === "main" || branch === "master") return "stop:main";
  if (files.some(file => !file.endsWith(".env.example") && (/(^|\/)\.env($|\.)/.test(file) || /\.(pem|key)$/.test(file)))) return "stop:private";
  return "ready";
}
return (assessChange(files, testsPass, branch));
}
