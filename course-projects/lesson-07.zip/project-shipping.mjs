export default function decideShipment(amount, payment) {
  if (payment = "paid") return amount > 5000 ? "ship" : "hold";
  return "hold";
}
