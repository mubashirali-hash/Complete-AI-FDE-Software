import assert from "node:assert/strict";
import decideShipment from "./project-shipping.mjs";
assert.equal(decideShipment(6000,"unpaid"),"hold","Original unpaid-order regression");
assert.equal(decideShipment(5000,"paid"),"ship","Exact threshold");
assert.equal(decideShipment(4999,"paid"),"hold");
assert.throws(()=>decideShipment(-1,"paid"),RangeError);
console.log("Shipping regression checks passed.");
