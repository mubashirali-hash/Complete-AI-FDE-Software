# A reviewed shipping fix

Create a real local Git repository containing your lesson 6 repair, its tests, and run instructions. Share a reviewable branch if you use GitHub.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- The repaired program and check command.
- A feature branch with a focused commit.
- A README and short review description.

## Milestone 1: Set up the folder

1. Check Node and Git versions.
2. Download and unzip the exercise kit into a new folder.
3. Run its check command and read the output.
4. Run node project-check-shipping.mjs; the supplied project file intentionally reproduces the bug.

## Milestone 2: Make the change

1. Initialise Git and record a starting version.
2. Create feature/shipping-fix.
3. Review git diff, stage the intended files, and commit.

## Milestone 3: Hand it to another person

1. Record the commit id and check result.
2. Try the README in a clean second folder.
3. Write the problem, behaviour, and validation in the review description.

## Acceptance

- [ ] The project runs using its README.
- [ ] The repair is on a feature branch.
- [ ] The diff contains only intended changes.
- [ ] The regression checks pass.
- [ ] No real credentials or private files are committed.

## Tests to reproduce

- Clean second folder: The documented command runs the checks.
- The original unpaid-order case: The repaired program holds it.
- Review of the staged diff: Only intended files and empty configuration placeholders.

## Independent extension

Ask someone to review the change and address one concrete piece of feedback. Record what changed and why.

## Explain your work

- What is the difference between Git and GitHub?
- What did reviewing the diff reveal?
- Which instruction made the project reproducible?
