# Set up your workspace and review a change

Amina wants a teammate to use your shipping fix. They need the files, the steps to run them, and a clear record of what changed.

## A folder, an editor, and a terminal

A project is a folder containing related files. An editor helps you read and change them. A terminal accepts commands that run programs or work with files. Run one command at a time and read its output before moving on.

Install Node.js and Git using their official downloads. In your terminal, node --version and git --version should print their versions. Open a new terminal after installing a tool if the old terminal cannot find it. Keep your work in a new learning folder, separate from other projects.

## Keep a history with Git

Git records versions of files. A repository is a folder with that history. A commit is a saved change with a message explaining its purpose. Git works locally; GitHub is a service where you can share a repository and review proposed changes.

Start with git init in your learning folder. Use git status to see changed files. Select the intended files with git add, then make a commit. Avoid adding everything blindly: look for private files, temporary output, and unrelated changes first.

## Review a small branch

A branch is a named line of work. Use git switch -c feature/shipping-fix to create a branch for the repair. A diff shows what changed between versions. Read it with git diff before committing.

A useful review explains the problem, resulting behaviour, and tests. Include the unpaid-order reproduction from lesson 6. The browser exercise below checks a release decision; it does not run Git. The project requires real commands and a real commit in your own workspace.

## Make the work reproducible

Another developer should be able to obtain the project and run its checks using the README. Record the runtime version, file names, command, and expected result. A clean second folder is a useful test of those instructions.

Keep API keys and other private configuration out of the repository. An .env.example can contain empty placeholders and descriptions. Filename checks are only one guard: a secret can appear inside any file, so review the contents of the diff too.

## Worked example

```javascript
const branch = "feature/shipping-fix";
const testsPass = true;
console.log(branch !== "main" && testsPass);
```

true

- The branch name describes the change.
- testsPass records whether the checks succeeded.
- Both conditions must hold before this simplified workflow proceeds. Real review also examines the diff.

## Further reading

- [Git book: getting started](https://git-scm.com/book/en/v2/Getting-Started-About-Version-Control)
- [Node.js downloads](https://nodejs.org/en/download)
