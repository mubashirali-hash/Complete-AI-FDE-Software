# Orders that survive a restart

Create a SQLite file with customers, products, and orders. Record an order and stock change in one transaction.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A schema and sample-data script.
- Parameterized query functions.
- A persistence and rollback test report.

## Milestone 1: Store real data

1. Create a database file and enable foreign keys.
2. Give rows primary keys and connect an order to a customer.
3. Close the connection and reopen the file.

## Milestone 2: Query safely

1. Reuse the shop and minimum query.
2. Bind all user values.
3. Test apostrophes, missing shops, and empty data.

## Milestone 3: Protect a purchase

1. Group order insertion and stock reduction in a transaction.
2. Fail when stock is insufficient.
3. Verify that neither partial change remains after the failure.

## Acceptance

- [ ] Rows survive reopening the database.
- [ ] Queries bind values.
- [ ] Orders reference existing customers.
- [ ] Negative stock cannot be committed.
- [ ] Failed purchases leave both tables unchanged.

## Tests to reproduce

- Reopen the file: The previously created order is present.
- Apostrophe in a shop name: Only the exact shop matches.
- Purchase more than available stock: No order or stock change is committed.

## Independent extension

Add a migration that introduces order status. Test it on a copy of an older database and restore the backup.

## Explain your work

- What does the browser’s in-memory database prove?
- Why does binding a value prevent it changing the query?
- Which two changes must be atomic in your project?
