import json
from starter import exercise
cases=json.loads("[{\"id\":\"all\",\"label\":\"Read all Amina rows\",\"args\":[[[1,\"amina\",900],[3,\"amina\",1500]],\"amina\",0],\"expected\":[[1,900],[3,1500]],\"why\":\"Read the selected columns in order.\"},{\"id\":\"empty\",\"label\":\"An empty table\",\"args\":[[],\"amina\",0],\"expected\":[],\"why\":\"An empty query is still successful.\"},{\"id\":\"shop\",\"label\":\"Two shops share a table\",\"args\":[[[1,\"amina\",900],[2,\"bilal\",1200],[3,\"amina\",1500],[4,\"O'Reilly\",500]],\"amina\",0],\"expected\":[[1,900],[3,1500]],\"why\":\"Other shops must stay out of the result.\"},{\"id\":\"apostrophe\",\"label\":\"A shop name with punctuation\",\"args\":[[[1,\"amina\",900],[2,\"bilal\",1200],[3,\"amina\",1500],[4,\"O'Reilly\",500]],\"O'Reilly\",0],\"expected\":[[4,500]],\"why\":\"Bound parameters support ordinary punctuation.\"},{\"id\":\"injection\",\"label\":\"Text that looks like a SQL condition\",\"args\":[[[1,\"amina\",900],[2,\"bilal\",1200],[3,\"amina\",1500],[4,\"O'Reilly\",500]],\"amina' OR 1=1 --\",0],\"expected\":[],\"why\":\"Input text must not become a command.\"},{\"id\":\"minimum\",\"label\":\"A minimum total\",\"args\":[[[1,\"amina\",900],[2,\"bilal\",1200],[3,\"amina\",1500],[4,\"O'Reilly\",500]],\"amina\",1000],\"expected\":[[3,1500]],\"why\":\"The second condition narrows the result.\"},{\"id\":\"boundary\",\"label\":\"The exact minimum\",\"args\":[[[1,\"amina\",900],[2,\"bilal\",1200],[3,\"amina\",1500],[4,\"O'Reilly\",500]],\"amina\",900],\"expected\":[[1,900],[3,1500]],\"why\":\"At least includes equality.\"}]")
for case in cases:
    try:
        actual=exercise(*case.get('args',[]))
    except Exception as error:
        assert case.get('error')==type(error).__name__, (case['id'],str(error))
    else:
        assert not case.get('error') and json.dumps(actual,sort_keys=True)==json.dumps(case.get('expected'),sort_keys=True), (case['id'],actual,case.get('expected'))
    print('PASS',case['label'])
print('Exercise checks passed. Complete PROJECT.md separately.')
