def exercise(rows, shop, minimum):
    import sqlite3
    connection = sqlite3.connect(":memory:")
    connection.execute("CREATE TABLE orders(id INTEGER PRIMARY KEY, shop TEXT NOT NULL, total INTEGER NOT NULL)")
    connection.executemany("INSERT INTO orders VALUES (?, ?, ?)", rows)
    def find_orders(shop, minimum):
        return []
    return (find_orders(shop, minimum))
