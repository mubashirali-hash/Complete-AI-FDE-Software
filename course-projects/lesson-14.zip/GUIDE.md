# Save and find orders with SQL

Amina wants her orders to survive a restart. She also shares the service with another shop. Find the right shop’s orders without trusting text as SQL commands.

## A table holds records

A SQLite database is stored in a file in the local project. A table has named columns and rows. orders has id, shop, and total columns. A primary key identifies a row; a foreign key can connect an order to a customer row.

The browser lab uses a real in-memory SQLite database for repeatable tests. That database lasts only for the exercise run. The project changes the connection to a file and checks that records survive closing and reopening it.

## Select only the rows you need

SELECT id, total chooses columns. FROM orders chooses a table. WHERE shop = ? AND total >= ? adds conditions. ORDER BY id makes the result predictable. A query returns rows; it does not remove the unmatched rows.

Write the intended result before the query. For Amina and minimum 1000, only order 3 should appear. An empty result is a normal result, not proof that the database failed.

## Keep values separate from SQL

Pass values as a parameter tuple: connection.execute(sql, (shop, minimum)). The database binds those values to the question marks. A shop name containing an apostrophe remains a value.

Do not construct SQL by inserting shop text into the query. Parameter binding applies to values; table or column names need an explicit allowed list when they are dynamic. The tests include an attempted SQL condition in the shop name.

## Make related changes together

A transaction groups changes so they commit together or roll back together. Creating an order and reducing stock should not leave only half the operation saved. Use with connection: for a local transaction and raise an error if stock would become negative.

Enable PRAGMA foreign_keys = ON for every SQLite connection that uses foreign keys. Add constraints such as CHECK(total >= 0). Back up a database before a schema migration, and verify the restored copy rather than assuming a copied file is usable.

## Worked example

```python
sql = "SELECT id, total FROM orders WHERE shop = ? AND total >= ? ORDER BY id"
result = connection.execute(sql, ("amina", 1000)).fetchall()
print(result)
```

[(3, 1500)] for the supplied orders

- The SQL selects two columns and two conditions.
- The tuple supplies values without changing the SQL command.
- ORDER BY makes the returned order deterministic.

## Further reading

- [Python sqlite3](https://docs.python.org/3/library/sqlite3.html)
