# An inbox for phones and laptops

Deliver a message board that remains readable with long content and at different widths. Keep the semantic HTML intact.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- Responsive HTML/CSS.
- Small and wide screenshots or a recorded walkthrough.
- A short explanation of the breakpoint.

## Milestone 1: Start small

1. Use one column and edge padding.
2. Try a narrow phone viewport.

## Milestone 2: Add space wisely

1. Use two columns when enough width is available.
2. Limit the maximum width of long content.

## Milestone 3: Check awkward content

1. Try a long message and browser zoom.
2. Check horizontal scrolling, focus, and button size.

## Acceptance

- [ ] A narrow view uses one column.
- [ ] A wide view uses two columns.
- [ ] There is no document-level horizontal scroll.
- [ ] Buttons and focus are comfortable to use.
- [ ] Long content and zoom are included in the evidence.

## Tests to reproduce

- A 320px-wide view: One column with readable content.
- A 900px-wide view: Two columns.
- A long message: Content wraps instead of hiding outside the page.

## Independent extension

Add an empty-inbox state and check that its spacing remains clear on both layouts.

## Explain your work

- Why use available width rather than a device name?
- What caused an overflow during testing?
- How did zoom affect the layout?
