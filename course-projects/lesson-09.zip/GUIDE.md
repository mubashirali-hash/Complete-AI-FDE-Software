# Make the inbox fit a phone

Amina checks messages on her phone. A page that looks fine on a laptop can still hide content or make buttons too small on a phone.

## CSS controls presentation

CSS describes appearance and layout: spacing, colours, sizes, and where elements are placed. A selector chooses which elements receive a rule. For example, .grid chooses elements with class="grid".

Keep the HTML meaning from lesson 8 while changing presentation. A page should remain understandable if its styles fail to load. Use enough contrast and space to make the content readable, rather than depending on decoration to explain the task.

## Start with the narrow layout

A single column is a useful starting point for a small phone. CSS Grid can arrange the message cards with a consistent gap. grid-template-columns: 1fr makes one column that uses the available space.

Avoid giving the entire page a fixed width such as 900px. A max-width can limit a wide layout while allowing it to shrink. Padding gives the text room at the edges. min-width: 0 lets a grid item shrink instead of forcing the page to overflow.

## Add a wider-screen rule

A media query applies styles under a condition. @media (min-width: 600px) applies when the preview is at least 600 CSS pixels wide. At that size, two columns can be useful.

The condition is about available layout space, not a particular phone model. Test both sides of the breakpoint. Also test long content and browser zoom: the page should adapt when text needs more room.

## Make actions comfortable

A button needs enough area to press and a clear focus outline for keyboard use. In this project, give it a minimum height of 44px and readable text. Do not remove the browser’s focus indication without replacing it.

The browser checks inspect the current preview width. Your project evidence should include both a small and a wide view. The course’s browser tests also exercise reference layouts at both widths.

## Worked example

```html
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Amina's shop</title><style>body{font-family:system-ui}.grid{display:grid;grid-template-columns:1fr;gap:16px}@media(min-width:600px){.grid{grid-template-columns:repeat(2,1fr)}}</style></head><body><main><h1>Amina’s inbox</h1><div class="grid"><article>Order 1: Tea</article><article>Order 2: Coffee</article></div><button>Open an order</button></main></body></html>
```

One column in a narrow view; two columns when at least 600px wide.

- The base rule works on a narrow screen.
- Grid creates columns with a consistent gap.
- The media query adds a wider layout without changing the content.

## Further reading

- [MDN responsive design](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design)
