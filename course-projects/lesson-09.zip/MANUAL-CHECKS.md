# Inspect the rendered result

- Cards use a grid: The cards need an explicit layout rule.
- There is readable space between cards: Adjacent cards should not appear as one cramped block.
- The columns match the current preview width: Check the layout on each side of the breakpoint.
- The page fits the preview: Hidden horizontal content makes a phone layout hard to use.
- The action is large enough to press: An action needs a comfortable visible target.

Check at 320px and 900px widths, with keyboard input. The course browser also executes these behaviour checks. Project acceptance requires the broader tests in PROJECT.md.
