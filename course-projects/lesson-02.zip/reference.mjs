export default async function exercise(current,incoming,answered,urgent) {

let result = "normal";
if (![current, incoming, answered].every(Number.isInteger) || current < 0 || incoming < 0 || answered < 0 || answered > current + incoming) {
  result = "invalid";
} else if (urgent) {
  result = "urgent";
}
return (result);
}
