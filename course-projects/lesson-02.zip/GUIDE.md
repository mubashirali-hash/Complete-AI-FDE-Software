# Make decisions and reject bad input

Amina wants urgent messages at the top of her queue. She also wants the app to reject impossible numbers instead of quietly accepting them.

## A program can choose

A condition is a question with a true or false answer. Is this message urgent? Is this number below zero? An if instruction runs a block of code when its condition is true.

A boolean is a value that is either true or false. In our exercise, urgent is a boolean supplied by the lesson. Writing if (urgent) means: use this branch when urgent is true. A default result covers the other situation.

## Valid input comes first

Validation checks whether information is acceptable before a program uses it. A message count must be a whole number at least zero. A count of -2 is impossible. A count of 1.5 does not represent a whole message.

Number.isInteger(value) checks for a whole number in JavaScript. It also rejects text such as "2". The expression value < 0 checks for a negative number. We reject bad values before deciding whether the queue is urgent.

## More than one rule

The symbol || means or: reject the input if any listed problem is present. The symbol ! means not: !Number.isInteger(current) is true when current is not a whole number.

Order matters. First check the counts. Next check that answered is no larger than current + incoming. Only then choose urgent or normal. Otherwise a request could receive an urgent label even though its numbers are invalid.

## Write rules people can explain

A useful rule has a reason. Rejecting a negative arrival count protects the meaning of the data. Rejecting too many answered messages prevents a negative remaining count. Routing urgent messages helps Amina decide what to handle first.

Keep the result vocabulary small: normal, urgent, or invalid. A later interface can show a helpful message for each result. Test one example for every branch so a change to one rule does not accidentally remove another.

## Worked example

```javascript
let quantity = -1;
let result = "accepted";
if (!Number.isInteger(quantity) || quantity < 0) {
  result = "invalid";
}
console.log(result);
```

invalid

- The default result starts as accepted.
- The condition checks two problems: a non-whole number or a negative number.
- The condition is true for -1, so the program changes result to invalid.

## Further reading

- [JavaScript decisions](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Conditionals)
