# A queue rule Amina can trust

Write a small decision service that accepts counts and an urgency flag, then returns one clear result.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A decision program with three named results.
- A table of valid and rejected inputs.
- A customer-facing explanation for invalid input.

## Milestone 1: Route work

1. Describe normal and urgent in plain English.
2. Implement and test both branches.

## Milestone 2: Reject impossible work

1. Validate every count.
2. Check the exact boundary where all messages are answered.

## Milestone 3: Explain rejection

1. Describe which input rule was broken.
2. Keep the priority rule separate from validation.

## Acceptance

- [ ] Valid ordinary work returns normal.
- [ ] Valid urgent work returns urgent.
- [ ] Text, fractions, and negative counts are rejected.
- [ ] Too many answered messages are rejected.
- [ ] The exact valid boundary is tested.

## Tests to reproduce

- Negative incoming count: invalid
- Urgent work with valid counts: urgent
- All available messages answered: normal

## Independent extension

Add a separate message describing the first validation problem. Keep the result vocabulary unchanged.

## Explain your work

- Why should validation happen before routing?
- Which boundary did you test?
- How would the interface explain invalid input?
