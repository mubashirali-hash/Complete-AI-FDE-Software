export default async function exercise(current,incoming,answered,urgent) {

let result = "normal";
return (result);
}
