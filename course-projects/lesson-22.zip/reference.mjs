export default async function exercise(query,documents,k) {

function cosine(a,b){const dot=a.reduce((sum,value,i)=>sum+value*b[i],0);const normA=Math.sqrt(a.reduce((sum,value)=>sum+value*value,0));const normB=Math.sqrt(b.reduce((sum,value)=>sum+value*value,0));return normA&&normB?dot/(normA*normB):0;}
function rank(query,documents,k){if(!Number.isInteger(k)||k<=0)return [];return documents.map(doc=>({id:doc.id,score:cosine(query,doc.vector)})).filter(item=>item.score>=0.7).sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id)).slice(0,k).map(item=>item.id);}
return (rank(query,documents,k));
}
