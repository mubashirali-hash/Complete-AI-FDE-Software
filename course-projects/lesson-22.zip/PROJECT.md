# A policy search with permission filters

Index a small policy corpus for two shops. Compare lexical retrieval with real embeddings if available, and label which mode each report uses.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- Versioned policy chunks and metadata.
- A filtered retrieval endpoint.
- A labelled retrieval evaluation report.

## Milestone 1: Prepare sources

1. Write returns, delivery, and hours policies.
2. Assign stable ids, shop ids, and versions.
3. Create questions with expected source ids.

## Milestone 2: Implement retrieval

1. Filter by the verified shop before ranking.
2. Use the same embedding model for query and documents.
3. Handle empty, zero, and incompatible vectors.

## Milestone 3: Evaluate and update

1. Record top ids for every question.
2. Compare paraphrases and missing-answer cases.
3. Change one policy and rebuild its index.

## Acceptance

- [ ] Results are scoped to the verified shop.
- [ ] Source ids and versions are retained.
- [ ] Weak or missing matches can return empty.
- [ ] Real vectors and teaching fixtures are distinguished.
- [ ] A changed policy causes a verified index update.

## Tests to reproduce

- A paraphrased returns question: The labelled returns source appears in top results.
- Only another shop has a matching policy: No unauthorized text is returned.
- An unknown policy question: The system can return no evidence.

## Independent extension

Measure recall at different k values and explain the quality, latency, and context-size tradeoff.

## Explain your work

- Why normalize vectors?
- Where do permission filters belong?
- Which retrieval failure did your evaluation reveal?
