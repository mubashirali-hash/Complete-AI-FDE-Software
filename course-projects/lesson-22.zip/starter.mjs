export default async function exercise(query,documents,k) {

function rank(query,documents,k){return [];}
return (rank(query,documents,k));
}
