# Find the policy that answers a question

Amina’s assistant needs the returns policy for a returns question. Search must find the right shop’s current document before an answer can use it.

## Represent meaning as a vector

An embedding model maps text into a numeric vector. Nearby vectors can indicate related meanings according to that model. Use the same model and compatible dimensions for documents and queries.

The lab supplies small two-dimensional vectors to make arithmetic visible. They are invented teaching vectors, not model embeddings. The project uses a real embedding adapter or records a lexical baseline when the provider is unavailable.

## Normalize before comparing

A dot product multiplies corresponding values and adds them. Cosine similarity divides the dot product by both vector lengths, so a longer vector does not win merely because its numbers are larger. Handle a zero vector deliberately.

Rank by descending score and break ties consistently by document id. Limit the number of returned chunks. A threshold such as 0.7 is a teaching policy; choose a real threshold using retrieval evaluations on your corpus.

## Prepare and filter the documents

Split long documents into useful chunks and store source id, shop, version, and text with each vector. Avoid fragments that lose the context needed to interpret a rule. Track when policy content changes and rebuild the corresponding embeddings.

Apply permission and shop filters before returning text to the model. Similarity is not authorization. A highly similar document from another shop must remain unavailable to the caller.

## Evaluate retrieval separately

For each question, label which source should be found. Measure whether it appears in the top results, including paraphrases, missing answers, stale documents, and cross-shop content. Compare against a simple keyword search.

If retrieval fails, changing the answer prompt may not help. Inspect chunking, filters, model version, and ranking independently. Keep the actual retrieved ids and scores in a safe evaluation report.

## Worked example

```javascript
function cosine(a,b){const dot=a.reduce((sum,value,i)=>sum+value*b[i],0);const normA=Math.sqrt(a.reduce((sum,value)=>sum+value*value,0));const normB=Math.sqrt(b.reduce((sum,value)=>sum+value*value,0));return normA&&normB?dot/(normA*normB):0;}
console.log(cosine([1,0],[2,0]));
```

1

- The dot product is 2.
- The vector lengths are 1 and 2.
- Dividing by both lengths gives the same-direction score of 1.

## Further reading

- [OpenAI embeddings](https://developers.openai.com/api/docs/guides/embeddings)
