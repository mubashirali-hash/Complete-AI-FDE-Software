export default async function exercise(input,output,limit) {

function budget(input,output,limit){return 0;}
return (budget(input,output,limit));
}
