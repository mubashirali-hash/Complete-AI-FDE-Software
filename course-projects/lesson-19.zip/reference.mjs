export default async function exercise(input,output,limit) {

function budget(input,output,limit){if(![input,output,limit].every(Number.isInteger)||Math.min(input,output,limit)<0)throw new RangeError("Invalid budget");const cost=input*2+output*8;return {cost,allowed:cost<=limit};}
return (budget(input,output,limit));
}
