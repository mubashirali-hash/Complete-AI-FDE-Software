# An AI task worth testing

Write a classifier experiment brief and compare a deterministic baseline with real model results when you have a server-side key and account budget. Keep the two reports separate.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A task and error-cost brief.
- A labelled message dataset and baseline.
- An experiment report with usage, latency, and limits.

## Milestone 1: Define the task

1. Choose three categories and a human fallback.
2. Write examples of costly mistakes.
3. Define what counts as improvement.

## Milestone 2: Establish a baseline

1. Label at least 20 representative messages.
2. Run a simple keyword classifier.
3. Record errors before changing it.

## Milestone 3: Run a bounded experiment

1. Configure the model and key on the server.
2. Set output, timeout, and spending limits.
3. Record real outputs and usage or explicitly mark the experiment not run.

## Acceptance

- [ ] The task has checkable labels.
- [ ] Costs of errors are stated.
- [ ] The baseline result is recorded.
- [ ] Fixture and model evidence are separate.
- [ ] Limits and an escalation path are documented.

## Tests to reproduce

- Ambiguous message: Human review is an allowed outcome.
- Budget too small: Request is stopped before spending.
- Real model unavailable: No real accuracy claim is made.

## Independent extension

Compare two prompt versions on a held-out set without repeatedly tuning to that set.

## Explain your work

- Why might a simple baseline be sufficient?
- Which token counts did you observe rather than estimate?
- Which mistake must always reach a person?
