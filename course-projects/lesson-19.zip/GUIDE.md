# Choose a useful AI task and set a budget

Amina spends time sorting customer messages. An AI classifier could suggest categories, but it must stay within a budget and let staff handle uncertain cases.

## A model predicts a response

A language model produces tokens based on its input and learned patterns. It can classify, draft, and explain, but a convincing response can still be wrong. Give it a task with a clear outcome that you can check.

For the shop, begin with suggesting order, refund, or other. Keep actual refunds and record changes under service rules and human approval. Compare this with a simple keyword baseline: AI should earn its extra complexity with measured improvement.

## Tokens are units of model input and output

A token is a piece used by the model’s text representation; it is not always one word or character. Instructions, conversation, and retrieved context contribute to input. The generated answer contributes to output. Use the chosen provider’s tokenizer or returned usage when accuracy matters.

The lab receives token counts directly. Its rates of 2 and 8 fictional units per token are deliberately invented. For a real project, read the current pricing for your configured model and record the date and units. Never treat this arithmetic as a current price quote.

## Plan and observe spending

Set an input limit, a maximum output, a request timeout, and an overall budget. Check estimated maximum cost before the request, then record actual usage and latency after it. A retry also uses budget.

Shorter context is not automatically better: removing the policy needed to answer can lower quality. Compare quality, latency, and cost on the same examples. Keep the key on the server and let an account owner set the real spend limit.

## Define uncertainty and escalation

A model’s stated confidence is not a calibrated probability unless you establish that with evaluation. Use confidence as one signal and measure failures against labelled data. Decide which errors need human review before building the automation.

The project records a deterministic baseline and a real-model experiment separately. Browser fixtures teach control logic without a paid call. They cannot prove the accuracy, latency, or cost of a real model.

## Worked example

```javascript
function budget(input,output){return input*2+output*8;}
console.log(budget(100,20));
```

360 fictional units

- Input and output counts are supplied, not guessed from word length.
- Each count uses its own invented rate.
- The sum is an estimate in the exercise’s stated units.

## Further reading

- [OpenAI API quickstart](https://developers.openai.com/api/docs/quickstart)
- [OpenAI token guidance](https://developers.openai.com/api/docs/guides/text)
