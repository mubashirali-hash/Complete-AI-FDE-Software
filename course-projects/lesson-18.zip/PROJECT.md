# A full-stack release rehearsal

Release the local shop workspace from a clean checkout. Use the included Docker option or documented local commands, and rehearse a failure and recovery.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- Integration and browser test evidence.
- A release and configuration checklist.
- A rollback rehearsal with a smoke-test result.

## Milestone 1: Run connected tests

1. Use a disposable database.
2. Test sign-in, create, list, and denied access.
3. Exercise the connected frontend in a browser.

## Milestone 2: Build a reproducible release

1. Install from pinned dependencies.
2. Build the frontend and start the service.
3. Check health and a real create-message request.

## Milestone 3: Recover a deliberate failure

1. Record the last working version.
2. Back up and verify data.
3. Introduce a harmless local failure, restore, and repeat the smoke test.

## Acceptance

- [ ] The build starts from documented commands.
- [ ] Tests exercise real endpoint/database boundaries.
- [ ] Health reflects the database dependency.
- [ ] No private configuration enters the frontend bundle.
- [ ] The rollback restores a usable service and intended data.

## Tests to reproduce

- Clean checkout: Build and main flow succeed.
- Database unavailable: Health or requests report failure accurately.
- Rollback rehearsal: The verified version serves the main flow again.

## Independent extension

Add a CI job that runs these checks and retains a safe failure report. Document which checks still require a human rehearsal.

## Explain your work

- Which boundary did each test cover?
- What did your health check actually prove?
- What would code rollback leave unchanged in the database?
