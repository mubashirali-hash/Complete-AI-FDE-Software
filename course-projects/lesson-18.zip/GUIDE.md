# Test and release the whole service

Amina will depend on your system tomorrow morning. Before making it available, prove that its important paths work and that you can recover a failed release.

## Choose tests for the boundaries

A unit test checks a small rule such as quote. An integration test checks connected parts such as an endpoint, session, and database. A browser test checks what a person can do in the interface.

Use a few meaningful flows: sign in, create a message, retrieve it, deny another customer, and preserve a failed draft. Test both status and stored data. A mocked repository test alone cannot prove that the SQL and endpoint are connected correctly.

## Separate environments

Use disposable data for tests and local practice. Put environment-specific configuration in server variables. Keep real credentials out of the frontend bundle and repository.

Pin dependency versions and record the runtime version. Build the frontend from a clean checkout. A deployment package should be repeatable, so a teammate can reproduce what was released instead of relying on files left on your machine.

## Release with a checklist you can prove

Before deployment, run tests, rehearse migrations on a copy, verify required configuration, and check the service health endpoint. Health should communicate whether the service is ready to accept work, including the database dependency.

A green status is evidence only if the underlying check actually ran. The browser exercise plans a gate; it does not deploy. The project records command outputs, an HTTP smoke test, and a database reopen check.

## Practice rollback before an incident

Keep the previously working application version and a verified database backup. Document whether a migration is reversible; rolling back code alone may not undo a changed schema.

Rehearse recovery locally with a deliberate failing version. Restore the intended version and data, then repeat the main smoke flow. Do not declare recovery because a process starts: prove that a customer can complete the operation.

## Worked example

```python
def release(checks):
    for name in ("tests", "migration", "config", "health", "rollback"):
        if not checks.get(name):
            return "stop:" + name
    return "ready"
print(release({"tests": True, "migration": True, "config": True, "health": True, "rollback": False}))
```

stop:rollback

- The checks have a deliberate order.
- The first failed or missing check stops the gate.
- Ready is returned only when every required check has evidence.

## Further reading

- [FastAPI testing](https://fastapi.tiangolo.com/tutorial/testing/)
- [FastAPI deployment](https://fastapi.tiangolo.com/deployment/)
