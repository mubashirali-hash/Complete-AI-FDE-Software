def exercise(checks):
    
    def release(checks):
        for name in ("tests", "migration", "config", "health", "rollback"):
            if not checks.get(name):
                return "stop:" + name
        return "ready"
    return (release(checks))
