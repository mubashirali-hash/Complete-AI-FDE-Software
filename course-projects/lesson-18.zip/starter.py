def exercise(checks):
    
    def release(checks):
        return "ready"
    return (release(checks))
