import json
from starter import exercise
cases=json.loads("[{\"id\":\"tests\",\"label\":\"Tests failed\",\"args\":[{\"tests\":false,\"migration\":true,\"config\":true,\"health\":true,\"rollback\":true}],\"expected\":\"stop:tests\",\"why\":\"Broken behaviour cannot pass the gate.\"},{\"id\":\"ready\",\"label\":\"Every check verified\",\"args\":[{\"tests\":true,\"migration\":true,\"config\":true,\"health\":true,\"rollback\":true}],\"expected\":\"ready\",\"why\":\"A complete set of evidence permits review.\"},{\"id\":\"migration\",\"label\":\"Migration unverified\",\"args\":[{\"tests\":true,\"migration\":false,\"config\":true,\"health\":true,\"rollback\":true}],\"expected\":\"stop:migration\",\"why\":\"Stored data needs its own check.\"},{\"id\":\"config\",\"label\":\"Configuration missing\",\"args\":[{\"tests\":true,\"migration\":true,\"config\":false,\"health\":true,\"rollback\":true}],\"expected\":\"stop:config\",\"why\":\"A build may fail with wrong deployment settings.\"},{\"id\":\"health\",\"label\":\"Service is unhealthy\",\"args\":[{\"tests\":true,\"migration\":true,\"config\":true,\"health\":false,\"rollback\":true}],\"expected\":\"stop:health\",\"why\":\"A running process is not always ready.\"},{\"id\":\"rollback\",\"label\":\"Recovery not rehearsed\",\"args\":[{\"tests\":true,\"migration\":true,\"config\":true,\"health\":true,\"rollback\":false}],\"expected\":\"stop:rollback\",\"why\":\"Recovery needs evidence before release.\"},{\"id\":\"missing\",\"label\":\"No check evidence\",\"args\":[{}],\"expected\":\"stop:tests\",\"why\":\"Missing information is not success.\"}]")
for case in cases:
    try:
        actual=exercise(*case.get('args',[]))
    except Exception as error:
        assert case.get('error')==type(error).__name__, (case['id'],str(error))
    else:
        assert not case.get('error') and json.dumps(actual,sort_keys=True)==json.dumps(case.get('expected'),sort_keys=True), (case['id'],actual,case.get('expected'))
    print('PASS',case['label'])
print('Exercise checks passed. Complete PROJECT.md separately.')
