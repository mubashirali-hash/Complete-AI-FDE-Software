# Build an assistant that knows when to stop

Amina’s assistant can look up an order, retrieve a policy, and draft a reply. If it cannot finish, it should explain why instead of looping or trying unapproved actions.

## Write a workflow before adding an agent

A workflow describes the permitted states and transitions: receive a question, retrieve evidence, draft, validate, and finish or escalate. Start with a deterministic sequence when it meets the need.

An agent may choose an action based on model output. That choice adds uncertainty, so keep a small registry of permitted actions and a clear controller. Separate the controller from the model and tool adapters so the controller can be tested without a paid model call.

## Make stopping states visible

Use distinct completion, waiting, budget, approval, failed, and unknown-action states. The caller needs to know whether there is an answer, missing information, or required human action. Do not report a stopped workflow as a completed answer.

The lab processes prepared event names. lookup consumes one step; done completes; write requires approval; error fails. It is a controller exercise, not evidence of an autonomous model’s performance.

## Limit more than step count

Set maximum steps, elapsed time, provider tokens or cost, tool calls, retries, and repeated identical actions. Check limits before an operation and account for its actual result afterward. A retry is another operation.

Keep tool execution under server permissions. Validate the proposed action at every iteration. A stop condition must terminate work, including delayed responses and pending operations, rather than merely change a label in the interface.

## Test the worst transitions

Reproduce repeated lookup, malformed action, provider failure, approval change, timeout, and duplicate completion. Check both the reported state and the actual tool calls. A budget label is incorrect if another tool executes afterward.

For a real provider run, save a safe trace of chosen actions and outcomes without exposing private messages or credentials. Use those traces to add regression cases and compare whether an agent improves on the fixed workflow.

## Worked example

```javascript
function run(events,limit){if(!Number.isInteger(limit)||limit<0)throw new RangeError("Invalid step limit");let used=0;for(const event of events){if(used>=limit)return {state:"budget",used};if(event==="done")return {state:"done",used};if(event==="write")return {state:"approval",used};if(event==="error")return {state:"failed",used};if(event!=="lookup")return {state:"unknown",used};used++;}return {state:"waiting",used};}
console.log(run(["lookup","write","lookup"],3));
```

{"state":"approval","used":1}

- The lookup consumes a step.
- The write proposal stops at approval.
- The final lookup is never processed.

## Further reading

- [OpenAI function calling](https://developers.openai.com/api/docs/guides/function-calling)
