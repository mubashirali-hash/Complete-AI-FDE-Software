# A bounded shop assistant

Implement a controller using the actual service tool adapters. Compare a fixed workflow with an optional model-chosen workflow and keep their evaluation evidence separate.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A state/transition table.
- A controller with step, time, and cost limits.
- Tests proving no operations run after stopping.

## Milestone 1: Define the flow

1. List allowed states and tools.
2. Choose a fixed sequence as the baseline.
3. Write the human handoff outcome.

## Milestone 2: Add real adapters

1. Use scoped order lookup and policy retrieval.
2. Validate every proposed tool call.
3. Keep writes behind exact approval.

## Milestone 3: Prove termination

1. Count actual tool invocations in tests.
2. Reproduce repeated actions, timeout, and provider failure.
3. Assert that terminal states execute no later operations.

## Acceptance

- [ ] All actions pass a tool registry.
- [ ] Limits are checked before operations.
- [ ] Stopping reasons are visible.
- [ ] Approval and permissions remain server enforced.
- [ ] Tests inspect actual calls after stopping.

## Tests to reproduce

- Repeated identical lookup: The run stops within its limit.
- Write proposal: No simulated money changes before approval.
- Delayed provider result after timeout: No late tool operation begins.

## Independent extension

Persist a resumable run and prevent an expired approval from being reused after recovery.

## Explain your work

- Why begin with a fixed workflow?
- Which budget counts retries?
- How did you prove that stop actually stopped?
