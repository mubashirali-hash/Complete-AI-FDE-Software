export default async function exercise(events,limit) {

function run(events,limit){if(!Number.isInteger(limit)||limit<0)throw new RangeError("Invalid step limit");let used=0;for(const event of events){if(used>=limit)return {state:"budget",used};if(event==="done")return {state:"done",used};if(event==="write")return {state:"approval",used};if(event==="error")return {state:"failed",used};if(event!=="lookup")return {state:"unknown",used};used++;}return {state:"waiting",used};}
return (run(events,limit));
}
