export default async function exercise(state,event) {

function nextState(state, event) { return state; }
return (nextState(state, event));
}
