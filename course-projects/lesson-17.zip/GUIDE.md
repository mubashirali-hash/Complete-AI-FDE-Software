# Connect the page to the service

A customer writes a message. The connection drops just after they press Send. The page should keep their words and explain what is known about the request.

## Give each request a visible state

Represent idle, sending, saved, validation error, sign-in required, and connection failure explicitly. The page should tell a person what happened and what they can do next.

Use the same API contract on both sides. Send JSON, use the correct method and content type, and include the verified session and CSRF token as required. Parse and validate the response before treating it as a created message.

## Protect the draft

Keep the text while a request is in progress and when it fails. Clear it only after a validated successful response. Disable the Send button while waiting so repeated clicks do not create two simultaneous requests.

A failed network response may happen after the server stored the message. A retry may duplicate it. For important operations, use an idempotency key generated once for the attempted action and reused for a retry; the service should return the same outcome for that key.

## Connect real processes

Run the frontend and backend from the workspace. The development frontend proxy forwards /api to the local service. For production, the build can be served from the same origin. That avoids guessing cross-origin cookie settings.

The exercise uses prepared HTTP outcomes to teach the UI reducer. It does not make a real request. Your project must use fetch against the running service and inspect the network panel, including denied and invalid requests.

## Recover deliberately

Show validation errors next to the form. Show a sign-in action for an expired session. Offer a retry after a temporary connection problem, retaining the draft and idempotency key.

Cancel or ignore old responses when a component changes to another record. Test a slow request followed by a navigation. The most recent screen must not be overwritten by an older unrelated response.

## Worked example

```javascript
function nextState(state, event) {
  if (event === "send") return {...state, status: "sending"};
  if (event === "saved") return {draft: "", status: "saved"};
  return {...state, status: "retry"};
}
console.log(nextState({draft: "Hello", status: "sending"}, "network"));
```

{"draft":"Hello","status":"retry"}

- The spread keeps the existing draft.
- Only an acknowledged success clears text.
- A connection failure keeps a path to recovery.

## Further reading

- [MDN Fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch)
