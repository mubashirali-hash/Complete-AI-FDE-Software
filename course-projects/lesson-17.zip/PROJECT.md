# A connected message form

Connect the React form to the real service workspace. Demonstrate each request state using HTTP responses and a stopped service.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A frontend using the real API.
- Visible loading, success, and failure states.
- A duplicate/retry and draft-preservation report.

## Milestone 1: Make one real request

1. Start both processes using the README.
2. Sign in and obtain the CSRF token.
3. Submit text and retrieve the saved record.

## Milestone 2: Represent failure

1. Keep the draft during requests.
2. Show validation and sign-in actions.
3. Stop the service and inspect the connection-failure state.

## Milestone 3: Make retry reliable

1. Reuse one idempotency key for a retry.
2. Prevent a second in-flight submission.
3. Test that stale responses cannot overwrite a new screen.

## Acceptance

- [ ] The form calls the running backend.
- [ ] Response JSON is validated.
- [ ] Only confirmed success clears the draft.
- [ ] Duplicate and retry behaviour is documented and tested.
- [ ] A keyboard user can understand and recover from an error.

## Tests to reproduce

- Stop the backend then submit: Draft remains with a recovery action.
- Repeat the same idempotency key: Only one record is created.
- Expired session: Sign-in is requested without losing text.

## Independent extension

Add cancellation when switching between orders and reproduce a slow, stale response.

## Explain your work

- Which states does the person need to see?
- Why can a network error have an unknown outcome?
- Where is duplicate protection enforced beyond the button?
