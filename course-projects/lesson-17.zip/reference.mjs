export default async function exercise(state,event) {

function nextState(state,event){if(event==="send"&&state.status==="sending")return state;if(event==="send")return {...state,status:"sending"};if(event==="saved")return {draft:"",status:"saved"};const failures={invalid:"invalid",unauthorized:"signin",network:"retry"};return Object.hasOwn(failures,event)?{...state,status:failures[event]}:state;}
return (nextState(state, event));
}
