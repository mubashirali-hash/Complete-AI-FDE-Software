export default async function exercise(evidence) {

function readiness(evidence){return {ready:true,gaps:[]};}
return (readiness(evidence));
}
