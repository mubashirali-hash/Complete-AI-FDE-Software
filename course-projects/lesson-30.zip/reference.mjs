export default async function exercise(evidence) {

function readiness(evidence){const required=["build","debug","data","security","ai","delivery","explain","independent"];const gaps=required.filter(skill=>!evidence.some(item=>item.skill===skill&&item.verified===true&&item.independent===true&&typeof item.artifact==="string"&&item.artifact.trim()));return {ready:gaps.length===0,gaps};}
return (readiness(evidence));
}
