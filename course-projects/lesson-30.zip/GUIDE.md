# Demonstrate, hand over, and test your independence

Amina wants a teammate to run the product after your visit. A hiring reviewer also wants to see whether you can make and explain a change without following a solution.

## Demonstrate the customer outcome

Start the demo with the original problem and baseline. Show the main operation with realistic safe data, then one denied case and one recoverable failure. Explain what improved and what remains limited.

Be honest about the mode: an offline extractive or fixture demonstration does not prove real-model quality. Show the separate real-provider evaluation if you ran it. Give the reviewer the commit and commands needed to reproduce your claims.

## Hand over operation and ownership

Provide setup, architecture, API contract, data model, configuration placeholders, evaluation command, known limits, and recovery steps. Identify owners for deployment, incidents, data access, and policy updates.

Ask a teammate to start from a clean checkout and follow the runbook without your intervention. Record where they get stuck and improve the instructions. A handoff is successful when someone else can operate and diagnose the product.

## Complete an independent challenge

Choose an unseen requirement with a reviewer. Examples include expiring policies, a second shop workflow, duplicate retry protection, or a stale-response bug. Agree on acceptance before coding; do not open the course solution for that challenge.

You may use AI tools, as working engineers do. Keep a short record of suggestions you checked or rejected. Explain the code, tests, boundaries, tradeoffs, and one failure investigation in your own words. Independence means owning the result, not avoiding all tools.

## Use a readiness review with evidence

Review build, debugging, data, security, AI evaluation, delivery/recovery, explanation/handoff, and independent change. For each skill attach a reproducible artifact and have a reviewer verify it. A checked box or function output cannot verify that evidence.

The exercise practices a completeness rule. Its ready flag means the supplied records meet that rule, not that someone is guaranteed a job. If a skill has a gap, choose targeted practice and reassess. Beyond these 30 lessons, repeat projects with unfamiliar requirements and real team review.

## Worked example

```javascript
function readiness(evidence){const required=["build","debug","data","security","ai","delivery","explain","independent"];const gaps=required.filter(skill=>!evidence.some(item=>item.skill===skill&&item.verified===true&&item.independent===true&&typeof item.artifact==="string"&&item.artifact.trim()));return {ready:gaps.length===0,gaps};}
console.log(readiness([{skill:"build",verified:true,independent:true,artifact:"repo:change"}]));
```

ready is false; the other seven skill names appear in gaps

- The review names the required skills explicitly.
- Each needs a verified independent artifact record.
- Missing evidence produces a practice target, not a mastery claim.

## Further reading

- [GitHub README guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes)
