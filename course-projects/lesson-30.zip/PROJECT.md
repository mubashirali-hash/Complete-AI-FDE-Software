# A reviewer-run capstone and unseen change

Complete an independent requirement, demonstrate the product, and have another person verify the handoff and eight-skill readiness review.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- An independent change with acceptance and tests.
- A reproducible demo and handoff package.
- A reviewer-verified skill report and next-practice plan.

## Milestone 1: Own an unseen task

1. Agree on a new requirement and acceptance.
2. Build and debug without its reference solution.
3. Record AI assistance and how you checked it.

## Milestone 2: Hand over the system

1. Have a reviewer run a clean checkout.
2. Show main, denied, and failed/recovered paths.
3. Explain architecture, data, evaluation, and release decisions.

## Milestone 3: Review readiness

1. Attach evidence for all eight skills.
2. Ask the reviewer to reproduce important claims.
3. Choose a targeted project for each unverified skill.

## Acceptance

- [ ] The change meets independently agreed acceptance.
- [ ] You can explain and debug its code.
- [ ] A reviewer can run the project and recovery instructions.
- [ ] AI quality claims match the actual execution mode.
- [ ] The review identifies verified skills and unresolved gaps.

## Tests to reproduce

- Reviewer starts from a clean checkout: The runbook works without hidden setup.
- Reviewer changes a requirement: You can adapt and explain the tradeoff.
- A skill has no independent evidence: It remains a gap with a concrete practice task.

## Independent extension

Build a second capstone for a different customer workflow, work with a teammate, and repeat the independent review before applying the readiness claim to that context.

## Explain your work

- Which skill did the reviewer verify most convincingly?
- Which gap needs another project?
- What can you explain and change without the course solution?
