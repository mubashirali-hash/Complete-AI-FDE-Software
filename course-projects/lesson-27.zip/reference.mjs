export default async function exercise(requirements) {

function scope(requirements){const names=requirements.filter(item=>item.necessary===true&&item.measurable===true&&typeof item.task==="string").map(item=>item.task.trim()).filter(Boolean);return [...new Set(names)].slice(0,3);}
return (scope(requirements));
}
