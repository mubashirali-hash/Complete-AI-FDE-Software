export default async function exercise(requirements) {

function scope(requirements){return [];}
return (scope(requirements));
}
