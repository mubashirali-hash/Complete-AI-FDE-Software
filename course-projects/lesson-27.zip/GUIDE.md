# Understand the customer before choosing the build

Amina asks for “an AI that runs the shop.” You need to find the actual problem, agree on a useful first outcome, and explain which work belongs in a later release.

## Observe before proposing

Ask the customer to show the current task with safe sample data. Who does it, how often, what takes time, and what happens when it goes wrong? Listen for constraints such as unreliable connectivity, staff skills, privacy, and systems already in use.

An FDE works close to the customer, translates the need into software, and follows the result in use. This includes communication, data integration, debugging, deployment, and handoff. Choosing a model is only one implementation decision.

## Define an outcome and a baseline

An outcome describes a change for the customer: reduce median reply preparation time while maintaining supported answers. Measure the current workflow before setting a target. Define who reviews correctness and how ambiguous cases are handled.

Separate the desired outcome from a feature. “Use AI” is an implementation preference, not a success measure. A search page might solve the problem with less risk; compare that alternative honestly.

## Set scope and acceptance together

List must-have and later features. For each must-have, write a measurable acceptance condition, expected failure behaviour, and responsible reviewer. Include access rules, operations, and support work in the scope.

The exercise filters a prepared requirements list. It does not perform discovery or judge whether a stated requirement is truly necessary. The project requires an actual conversation or an explicitly labelled role-play, observations, and a customer-reviewed brief.

## Make tradeoffs visible

Document assumptions, dependencies, data access, risks, and open questions. State what the first release excludes and why. Record who can approve a scope change and how it affects cost and delivery.

Demonstrate a small working slice early using real customer constraints and safe data. Capture feedback and change the brief when evidence changes. A clear disagreement explained with evidence is more useful than silently building an unrealistic promise.

## Worked example

```javascript
function scope(requirements){const names=requirements.filter(item=>item.necessary===true&&item.measurable===true&&typeof item.task==="string").map(item=>item.task.trim()).filter(Boolean);return [...new Set(names)].slice(0,3);}
console.log(scope([{task:"Policy search",necessary:true,measurable:true},{task:"Animated logo",necessary:false,measurable:true}]));
```

["Policy search"]

- The supplied list distinguishes necessity and measurable acceptance.
- Only clear required tasks enter this small first-release list.
- This function cannot replace the conversation that establishes those labels.

## Further reading

- [GOV.UK understanding users](https://www.gov.uk/service-manual/user-research/start-by-learning-user-needs)
