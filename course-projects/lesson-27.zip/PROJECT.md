# A customer-reviewed brief

Interview a shop owner or conduct a clearly labelled role-play. Produce a first-release brief backed by observed tasks and measurable acceptance.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- Workflow observations and a baseline.
- A bounded brief with assumptions and exclusions.
- Reviewer feedback and resulting revisions.

## Milestone 1: Learn the current work

1. Ask for a demonstration with safe examples.
2. Record users, volume, errors, and constraints.
3. Separate observations from assumptions.

## Milestone 2: Write the agreement

1. Choose one customer outcome.
2. List first-release and later tasks.
3. Write measurable acceptance and failure behaviour.

## Milestone 3: Review with the customer

1. Walk through a simple prototype.
2. Record concerns and corrections.
3. Revise scope and identify the acceptance reviewer.

## Acceptance

- [ ] The problem follows observed work.
- [ ] The outcome has a baseline and measurement plan.
- [ ] Each required feature has acceptance conditions.
- [ ] Assumptions and exclusions are explicit.
- [ ] Feedback changes are recorded.

## Tests to reproduce

- Customer asks for automatic refunds: Risk and approval requirements are discussed before scope expands.
- No usable policy data: The dependency and fallback are documented.
- Prototype misses the staff workflow: Feedback produces a concrete brief revision.

## Independent extension

Compare the AI solution with a search-only alternative using the same outcome measure.

## Explain your work

- Which assumption changed after discovery?
- What is the customer outcome rather than the feature?
- Who decides whether acceptance is met?
