# Amina’s complete policy-assistant capstone

Use the workspace to deliver the customer-reviewed slice. Implement an independent feature and demonstrate both normal and denied/failing paths.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A runnable full-stack repository.
- Architecture, contract, and decision records.
- An integrated test and AI evaluation report.

## Milestone 1: Run and understand

1. Follow the clean setup instructions.
2. Trace one request across the actual files.
3. Identify fixture and real-provider modes.

## Milestone 2: Own a complete change

1. Choose a requirement from the reviewed brief.
2. Implement it across the necessary boundaries.
3. Add meaningful tests and document the decision.

## Milestone 3: Demonstrate the result

1. Show sign-in, scoped retrieval, citations, and review.
2. Reproduce provider, permission, and missing-source failures.
3. Ask a reviewer to run the project from the README.

## Acceptance

- [ ] The whole main flow runs from documented commands.
- [ ] Permissions apply before data reaches the model.
- [ ] Citations expose current permitted sources.
- [ ] Failures have honest recovery paths.
- [ ] An independent change has tests and reviewer evidence.

## Tests to reproduce

- Another shop session asks the question: No cross-shop source is exposed.
- Provider stopped or timed out: The interface shows the defined fallback.
- Clean checkout by a reviewer: The main flow and tests are reproducible.

## Independent extension

Add a second customer workflow and explain how it changes the architecture and evaluation requirements.

## Explain your work

- Which boundary caused the hardest integration failure?
- What did the reference help you understand?
- Which change can you defend without its solution?
