export default async function exercise(parts) {

function buildOrder(parts){return [];}
return (buildOrder(parts));
}
