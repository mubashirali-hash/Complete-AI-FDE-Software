# Build one complete customer workflow

Amina can now explain the first release: staff sign in, search current policies, get a cited draft, review it, and record the outcome. Build that whole path before adding more features.

## Draw the smallest complete system

Show the browser, API, session store, database, policy index, provider adapter, and diagnostic events. Mark where identity is verified, data is filtered, model output is validated, and writes require approval.

Explain each boundary with an input, output, and failure. Keep secrets on the server. The browser should receive only permitted data and public configuration. A diagram is useful when it predicts actual requests rather than merely lists technology names.

## Build a vertical slice

A vertical slice follows one customer action through all required layers. Start with sign-in, a policy question, scoped retrieval, a cited answer, and human review. Use an offline adapter first and label it clearly.

The downloadable workspace includes a runnable reference slice and extension tasks. Use it to understand boundaries, then complete an independent change. Copying a reference is practice evidence, not independent ownership of the system.

## Order dependencies and test failures

Data and contracts need to exist before clients depend on them. The lab topologically orders a dependency graph and rejects missing parts or cycles. This is a build-planning rule, not a deployment tool.

The real project tests disconnected and invalid paths: expired session, unavailable provider, missing policy, rejected approval, and duplicate retry. Capture expected/actual outcomes at each boundary and repair the earliest failing boundary.

## Keep the design understandable

Write short decision records for important choices such as same-origin serving, SQLite, adapter mode, and human approval. Describe the constraint, considered options, choice, and consequence. Prefer a system a teammate can operate and debug.

Keep a runnable main branch and focused reviewable changes. Connect the architecture diagram, API contract, data schema, evaluation report, and release runbook to the actual files and commands.

## Worked example

```javascript
function buildOrder(parts){const done=new Set();const active=new Set();const result=[];function visit(name){if(done.has(name))return;if(!Object.hasOwn(parts,name))throw new Error("Missing dependency: "+name);if(active.has(name))throw new Error("Cycle: "+name);active.add(name);for(const dependency of parts[name])visit(dependency);active.delete(name);done.add(name);result.push(name);}for(const name of Object.keys(parts))visit(name);return result;}
console.log(buildOrder({ui:["api"],api:["db"],db:[]}));
```

["db","api","ui"]

- The database is visited before its API dependent.
- Each completed part is included once.
- Missing dependencies and cycles stop the planner.

## Further reading

- [FastAPI larger applications](https://fastapi.tiangolo.com/tutorial/bigger-applications/)
