export default async function exercise(parts) {

function buildOrder(parts){const done=new Set();const active=new Set();const result=[];function visit(name){if(done.has(name))return;if(!Object.hasOwn(parts,name))throw new Error("Missing dependency: "+name);if(active.has(name))throw new Error("Cycle: "+name);active.add(name);for(const dependency of parts[name])visit(dependency);active.delete(name);done.add(name);result.push(name);}for(const name of Object.keys(parts))visit(name);return result;}
return (buildOrder(parts));
}
