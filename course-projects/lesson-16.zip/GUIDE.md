# Let the right person see the right data

Amina’s customers should see their own orders. Her staff can help customers in her shop. A staff member from another shop still cannot see Amina’s orders.

## Identify the person

Authentication establishes who is making a request. A service may verify a password and issue a session cookie. Later requests use that session to obtain the identity on the server.

Never accept a client’s user id, shop, or role as proof of identity. In the browser exercise the user dictionary is a trusted fixture supplied by the test. In the project, it must come from a verified server session.

## Decide what that person may do

Authorization checks permission for a specific operation and record. First deny missing identity. Next require the same shop. Finally allow shop staff or the customer who owns the order.

Keep the order important in the check: permission for order 1 does not imply permission for order 2. Check every read and write endpoint. Hiding a button in the interface does not prevent a direct request.

## Keep credentials and input controlled

Use a proven password hashing method with a salt and appropriate work factor. Store session tokens carefully, expire sessions, and invalidate them on logout. Production cookies need HTTPS, Secure, HttpOnly, and a considered SameSite policy.

A cookie-based write also needs protection against cross-site requests. The service workspace uses a CSRF token for state-changing requests. Validate input and bind database parameters even after authentication: a signed-in user can still send bad data.

## Test denied cases explicitly

Test a missing session, another customer in the same shop, a customer in another shop, and staff in another shop. A useful permission test proves the denied request cannot read or change the target record.

Choose a consistent response policy, including whether unauthorized callers can learn that a record exists. Keep detailed reasons out of public errors. Record a safe denial event with a request id rather than a password or session token.

## Worked example

```python
def can_read(user, order):
    if user is None or not user.get("shop") or user.get("shop") != order.get("shop"):
        return False
    return user.get("role") == "staff" or user.get("id") == order.get("customer_id")
print(can_read({"id": 7, "shop": "amina", "role": "customer"}, {"shop": "amina", "customer_id": 7}))
```

True

- A missing or mismatched shop is rejected first.
- Staff permission is scoped to the shop.
- A customer must own this particular order.

## Further reading

- [OWASP authorization guidance](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html)
- [OWASP session guidance](https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html)
