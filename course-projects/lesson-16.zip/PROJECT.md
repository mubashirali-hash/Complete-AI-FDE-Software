# A service with scoped access

Run the service workspace with two shops and two customer accounts. Connect permission checks to every protected endpoint.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A session-based service.
- An access matrix for roles and operations.
- Cross-customer and cross-shop HTTP tests.

## Milestone 1: Establish identity

1. Inspect the workspace password and session implementation.
2. Sign in using a prepared local account.
3. Verify that logout invalidates the session.

## Milestone 2: Enforce access

1. Obtain identity from the verified session.
2. Apply a shop and record check on each endpoint.
3. Prevent request fields from changing ownership.

## Milestone 3: Attempt denied requests

1. Use another customer session to request the record.
2. Try another shop’s staff session.
3. Verify denied writes leave the database unchanged.

## Acceptance

- [ ] Identity comes from a verified session.
- [ ] Customers see only their permitted records.
- [ ] Staff access stays within their shop.
- [ ] Cookie-based writes require the CSRF token.
- [ ] Logs omit passwords and session tokens.

## Tests to reproduce

- Another customer requests an order: Denied without exposing the order.
- Cross-shop staff requests it: Denied despite the staff role.
- Logout then repeat the request: The old session is rejected.

## Independent extension

Add an expiry test with a controlled clock and document how production HTTPS and cookie settings differ from localhost.

## Explain your work

- Why is hiding a button insufficient?
- Where does trusted identity come from?
- Which test proves a denied write did nothing?
