import json
from starter import exercise
cases=json.loads("[{\"id\":\"anonymous\",\"label\":\"No session identity\",\"args\":[null,{\"shop\":\"amina\",\"customer_id\":7}],\"expected\":false,\"why\":\"Anonymous callers are denied.\"},{\"id\":\"staff\",\"label\":\"Amina’s staff\",\"args\":[{\"id\":9,\"shop\":\"amina\",\"role\":\"staff\"},{\"shop\":\"amina\",\"customer_id\":7}],\"expected\":true,\"why\":\"Staff can support their own shop.\"},{\"id\":\"cross\",\"label\":\"Another shop’s staff\",\"args\":[{\"id\":9,\"shop\":\"bilal\",\"role\":\"staff\"},{\"shop\":\"amina\",\"customer_id\":7}],\"expected\":false,\"why\":\"The shop boundary comes before the role.\"},{\"id\":\"owner\",\"label\":\"The owning customer\",\"args\":[{\"id\":7,\"shop\":\"amina\",\"role\":\"customer\"},{\"shop\":\"amina\",\"customer_id\":7}],\"expected\":true,\"why\":\"Customers can read their own order.\"},{\"id\":\"other\",\"label\":\"Another customer in the same shop\",\"args\":[{\"id\":8,\"shop\":\"amina\",\"role\":\"customer\"},{\"shop\":\"amina\",\"customer_id\":7}],\"expected\":false,\"why\":\"Same shop alone is insufficient for a customer.\"},{\"id\":\"missing\",\"label\":\"Missing shop fields\",\"args\":[{\"id\":7},{\"customer_id\":7}],\"expected\":false,\"why\":\"Two missing values must not count as a valid shop match.\"}]")
for case in cases:
    try:
        actual=exercise(*case.get('args',[]))
    except Exception as error:
        assert case.get('error')==type(error).__name__, (case['id'],str(error))
    else:
        assert not case.get('error') and json.dumps(actual,sort_keys=True)==json.dumps(case.get('expected'),sort_keys=True), (case['id'],actual,case.get('expected'))
    print('PASS',case['label'])
print('Exercise checks passed. Complete PROJECT.md separately.')
