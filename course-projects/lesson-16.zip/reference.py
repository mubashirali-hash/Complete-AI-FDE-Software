def exercise(user, order):
    
    def can_read(user, order):
        if user is None or not user.get("shop") or user.get("shop") != order.get("shop"):
            return False
        return user.get("role") == "staff" or user.get("id") == order.get("customer_id")
    return (can_read(user, order))
