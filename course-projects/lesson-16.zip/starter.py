def exercise(user, order):
    
    def can_read(user, order):
        return True
    return (can_read(user, order))
