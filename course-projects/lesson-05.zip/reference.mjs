export default async function exercise(saved) {

function loadBasket(saved) {
  if (!saved) return [];
  try {
    const basket = JSON.parse(saved);
    if (!Array.isArray(basket) || !basket.every(item => item && typeof item.name === "string" && item.name.trim() !== "" && Number.isInteger(item.quantity) && item.quantity > 0)) return [];
    return basket.map(item => ({ name: item.name.trim(), quantity: item.quantity }));
  } catch { return []; }
}
return (loadBasket(saved));
}
