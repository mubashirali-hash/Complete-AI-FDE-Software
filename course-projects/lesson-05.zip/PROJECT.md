# A recoverable basket draft

Save a fictional basket as JSON text and load it using your recovery function. Begin with the supplied text cases; connect the function to real storage when you set up the local workspace in lesson 7.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A loader with a documented recovery policy.
- Saved JSON examples for valid and damaged data.
- A later reload check in your local app.

## Milestone 1: Read a good draft

1. Serialize a basket with JSON.stringify.
2. Load it and compare the records.

## Milestone 2: Recover deliberately

1. Try missing and damaged text.
2. Document when the loader returns an empty basket.

## Milestone 3: Check the storage boundary

1. Keep only approved fields.
2. After local setup, save, reload, and confirm the basket remains.

## Acceptance

- [ ] A valid basket loads correctly.
- [ ] Missing and damaged text have a known result.
- [ ] Invalid records are rejected.
- [ ] Unexpected fields are removed.
- [ ] A real reload is checked before claiming persistence.

## Tests to reproduce

- No saved text: Empty basket.
- Damaged text: Empty basket with the recovery policy explained.
- A valid saved basket after reload: The same approved records.

## Independent extension

Return a status beside the basket, such as missing, recovered, or loaded, so the interface can explain what happened.

## Explain your work

- What does parsing prove, and what does validation prove?
- Could returning [] hide valuable damaged data?
- What evidence would demonstrate real persistence?
