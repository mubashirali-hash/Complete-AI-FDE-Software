# Read saved data and recover from errors

Amina wants a basket to survive closing an app. Saved information is text, and that text can be missing, damaged, or an older shape. The app needs a safe recovery rule.

## Structured values and stored text

An object or array is useful while a program is running. Storage and network messages often carry text. JSON is a text format for representing values such as numbers, strings, arrays, and objects.

JSON.stringify changes a JavaScript value into JSON text. JSON.parse changes JSON text back into a value. Parsing does not prove that the value has the right shape for your application. A perfectly valid JSON number is still the wrong shape for a basket.

## Expect a saved record to be missing

A new user may have no saved basket. An application should choose a default, such as an empty array. The same is true after a user intentionally clears their data.

A variable in memory lasts only while that program is running. Durable storage, such as a file or database, keeps data for later. Browser storage is tied to an origin and browser profile. It is useful for a small personal draft, but it does not provide shared accounts or backend permissions.

## Catch the failure you expect

A try block contains an operation that may fail. A catch block handles the resulting error. If JSON.parse sees damaged text, it throws an error rather than guessing what you meant.

Recovering to an empty basket is an explicit policy for this practice app. A real product might preserve the damaged text and offer recovery before replacing it. Avoid silently deleting valuable customer records just to make an error disappear.

## Check every record after parsing

Our basket must be an array. Every item must have a non-empty name and a positive whole-number quantity. We accept the basket only when all items follow the rules. We return only the fields the application uses.

The browser exercise practises this recovery function with supplied saved text. The independent project connects it to storage and tests a reload. Keep the two checks distinct: reading valid data and proving that the app actually saves it.

## Worked example

```javascript
const saved = "[{\"name\":\"Tea\",\"quantity\":2}]";
try {
  const basket = JSON.parse(saved);
  console.log(basket[0].name);
} catch (error) {
  console.log("Could not read saved data");
}
```

Tea

- saved is text, including the JSON brackets and field names.
- JSON.parse creates the array of records.
- The try/catch gives a deliberate alternative if parsing fails. Shape validation still needs to be added.

## Further reading

- [JSON.parse](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/parse)
- [Browser storage](https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API)
