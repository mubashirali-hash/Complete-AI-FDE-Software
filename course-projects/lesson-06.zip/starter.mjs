export default async function exercise(amountCents,payment) {

function decideShipment(amountCents, payment) {
  if (amountCents > 5000 && (payment = "paid")) return "ship";
  return "hold";
}
return (decideShipment(amountCents, payment));
}
