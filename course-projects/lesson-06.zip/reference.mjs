export default async function exercise(amountCents,payment) {

function decideShipment(amountCents, payment) {
  if (!Number.isInteger(amountCents) || amountCents < 0) throw new RangeError("Invalid amount");
  if (amountCents >= 5000 && payment === "paid") return "ship";
  return "hold";
}
return (decideShipment(amountCents, payment));
}
