# A regression repair report

Deliver the shipping fix with evidence another developer can reproduce. Preserve the unpaid-order case and add one case you chose yourself.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A before/after reproduction.
- The corrected function and regression cases.
- A short repair report explaining the cause.

## Milestone 1: Reproduce the bug

1. Record the unpaid 6000-cent input.
2. Show expected hold and observed ship before the repair.

## Milestone 2: Repair the rule

1. Use comparison rather than assignment.
2. Correct the exact threshold and validation.

## Milestone 3: Protect and explain

1. Keep the original reproducing case.
2. Add a new test and explain what it covers.

## Acceptance

- [ ] A paid qualifying order still ships.
- [ ] The original unpaid-order case is held.
- [ ] The threshold boundary is correct.
- [ ] Invalid amounts are rejected.
- [ ] The report explains the cause and the evidence.

## Tests to reproduce

- 6000 cents, unpaid: hold
- 5000 cents, paid: ship
- 4999 cents, paid: hold
- Negative amount: RangeError

## Independent extension

Write your own regression case for an unknown payment status. Explain why a fail-safe result should be hold.

## Explain your work

- Which line caused the original problem?
- What would an example-specific patch have missed?
- What does a passing test suite still leave uncertain?
