# Find a bug and protect the fix with tests

The shop sometimes ships an unpaid order. Amina needs you to reproduce the problem, fix the actual rule, and keep a test that catches it if it returns.

## Start with evidence

Debugging means finding why a program behaves differently from its intended rules. Write down the input, expected result, and actual result before changing the code. A reproducible example lets another person see the same problem.

Our fictional rule says: ship a paid order worth at least 5000 cents; otherwise hold it. An unpaid order worth 6000 cents should be held. If the program ships it, its payment condition needs investigation.

## Read the suspicious line

The equals sign = assigns a value. The comparison === asks whether two values are equal. A line using payment = "paid" can change the input while the program is trying to decide what it means.

Repair the reason for the wrong result rather than special-casing one example. A fix that rejects only the exact amount 6000 leaves the same payment bug at other amounts. A good test should make the intended rule visible.

## Protect the boundary

At least 5000 includes exactly 5000. The operator >= expresses that rule. The operator > excludes the exact boundary. Test an amount just below, exactly at, and just above the threshold.

Negative and fractional-cent amounts are outside this exercise’s contract. Reject them with RangeError before considering shipping. This protects the decision from strange but apparently successful outputs.

## Keep a regression test

A regression is a previously fixed problem returning after a change. A regression test keeps the reproducing example and its expected result. Run it whenever the code changes.

A passing suite is evidence about the cases it covers. It cannot prove every possible behaviour is correct. Add a case when you discover a new failure, and explain which rule that case protects. The independent project asks you to write a new case of your own.

## Worked example

```javascript
function itemTotal(price, quantity) { return price + quantity; }
const expected = 15;
const actual = itemTotal(5, 3);
console.log({ expected, actual });
```

{"expected":15,"actual":8}

- The test expectation describes three items at a price of five.
- The actual result exposes the incorrect addition.
- The evidence points to the function’s arithmetic. Repair it to multiplication, then keep the case.

## Further reading

- [JavaScript equality](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Strict_equality)
