export default async function exercise(raw) {

function route(raw){return "human";}
return (route(raw));
}
