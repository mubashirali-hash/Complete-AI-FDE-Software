# Ask for structured output and check it

Amina needs a category that the application can use. A paragraph saying “probably a refund” is not the same as a valid, checked category record.

## State a precise task

A useful prompt explains the allowed categories, includes clear examples, and tells the model how to handle ambiguity. Separate application instructions from customer text. Customer text is data and can contain misleading instructions.

Start with an explicit output schema: category is order, refund, or other; confidence is a number from zero to one; no extra fields. Structured output constrains format. It does not prove the category is correct.

## Validate on the application boundary

Parse the returned JSON, verify the exact fields and allowed values, and reject malformed output. Handle provider refusals, incomplete results, and timeouts as explicit outcomes. Never pass a malformed response into a business operation.

The browser lab uses prepared JSON strings so each failure is reproducible. It does not contact a model. The server workspace has a separate real provider adapter controlled by environment variables and an offline adapter labelled fixture.

## Keep the provider behind an adapter

An adapter hides provider-specific request details behind a small application interface. The application can ask classify(message) and receive a validated result or a defined failure, while tests supply a fixture adapter.

Keep the API key on the server. Configure a supported model explicitly; do not bake a temporary model choice or key into the frontend. Record prompt, schema, adapter, and model versions with your evaluation result.

## Treat confidence as a policy signal

This lesson’s threshold is 0.7. It gives practice with a fallback rule; it is not a universal quality threshold. Choose a real threshold using labelled results and the relative costs of wrong routing and human review.

Changing a prompt can change meaning while preserving a schema. Rerun semantic evaluations after prompt, model, or policy changes. A successful schema check is one layer of evidence, followed by quality evaluation.

## Worked example

```javascript
function route(raw){let value;try{value=JSON.parse(raw);}catch{return "human";}if(!value||Array.isArray(value)||typeof value!=="object"||Object.keys(value).sort().join(",")!=="category,confidence"||!["order","refund","other"].includes(value.category)||typeof value.confidence!=="number"||!Number.isFinite(value.confidence)||value.confidence<0||value.confidence>1)return "human";return value.confidence>=0.7?value.category:"human";}
console.log(route('{"category":"refund","confidence":0.9}'));
```

refund

- Parsing is protected by try/catch.
- Field names, category, and numeric range are checked.
- Uncertain or invalid results go to human review.

## Further reading

- [OpenAI structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
