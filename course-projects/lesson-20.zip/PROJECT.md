# A replaceable classifier

Use the server adapter workspace to classify messages with a validated schema. Test fixtures first, then perform and label a real provider experiment.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A versioned prompt and schema.
- Fixture and real-provider adapters.
- Boundary and semantic evaluation reports.

## Milestone 1: Specify output

1. Define category meanings and examples.
2. Write the schema and fallback policy.
3. Save prompt and schema versions.

## Milestone 2: Implement the boundary

1. Test malformed, refused, incomplete, and valid outcomes.
2. Keep credentials on the server.
3. Reject output before routing when validation fails.

## Milestone 3: Measure meaning

1. Run labelled messages through the adapter.
2. Review wrong categories as well as invalid JSON.
3. Record whether the real provider experiment ran.

## Acceptance

- [ ] The application uses one adapter interface.
- [ ] Output is validated before routing.
- [ ] Provider failures produce a defined fallback.
- [ ] Keys remain on the server.
- [ ] Semantic results are recorded separately from schema checks.

## Tests to reproduce

- Malformed output: Human fallback without a crash.
- Unknown category: Rejected despite valid JSON.
- Valid but wrong category: Counted as an evaluation error.

## Independent extension

Add a provider timeout and a maximum single retry within the existing budget.

## Explain your work

- What does the schema prove?
- Which provider outcomes are not ordinary JSON answers?
- Why keep semantic evaluation after validation?
