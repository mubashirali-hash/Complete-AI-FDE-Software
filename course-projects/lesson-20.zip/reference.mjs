export default async function exercise(raw) {

function route(raw){let value;try{value=JSON.parse(raw);}catch{return "human";}if(!value||Array.isArray(value)||typeof value!=="object"||Object.keys(value).sort().join(",")!=="category,confidence"||!["order","refund","other"].includes(value.category)||typeof value.confidence!=="number"||!Number.isFinite(value.confidence)||value.confidence<0||value.confidence>1)return "human";return value.confidence>=0.7?value.category:"human";}
return (route(raw));
}
