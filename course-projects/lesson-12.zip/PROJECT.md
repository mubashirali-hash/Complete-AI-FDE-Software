# A typed React inbox

Rebuild the message inbox as components. Keep the business rules separate, validate external data, and run the TypeScript project check as well as the behaviour checks.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A React/TypeScript project.
- An inbox component and a message component.
- Type-check and interaction results.

## Milestone 1: Build one component

1. Represent the inbox with state.
2. Keep labels, buttons, and output meaningful.

## Milestone 2: Split a reusable piece

1. Pass a message record through typed props.
2. Use stable message ids when rendering a list.

## Milestone 3: Verify both kinds of check

1. Run the project’s type checker.
2. Check add, answer, empty, and reset interactions.
3. Keep runtime validation for loaded data.

## Acceptance

- [ ] The interface is rendered from state.
- [ ] Repeated state updates use the current value.
- [ ] Typed props describe the message record.
- [ ] The local project type check passes.
- [ ] Runtime validation and accessibility remain intact.

## Tests to reproduce

- Add twice quickly: The count increases by two.
- Answer until the inbox is empty: The count stops at zero.
- Use an incorrect prop field in a scratch change: The local type checker reports the mismatch.

## Independent extension

Add an asynchronous loading component that uses the adapter from lesson 11 and shows loading, empty, success, and error states.

## Explain your work

- What does React state replace in the DOM version?
- What does a type check catch?
- Why does external data still need runtime validation?
