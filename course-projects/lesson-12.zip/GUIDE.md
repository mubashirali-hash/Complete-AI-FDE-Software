# Use components, state, and types

The shop interface is growing. Amina wants reusable pieces that stay in step with their data, and the team wants help catching inconsistent field names before running the app.

## A component describes one piece of a page

A React component is a function that describes an interface. JSX lets that description look like markup inside JavaScript. A component can be reused and can receive inputs called props.

In this exercise, App is the component rendered in the preview. The import brings in React, and export default makes App the component the project uses. The browser runner compiles JSX before rendering the real React interface.

## State belongs to the component

React.useState starts a state value and returns a function for updating it. const [messages, setMessages] = React.useState<number>(10) starts the count at 10. Calling setMessages tells React to render using a new value.

For an update based on the previous value, use setMessages(previous => previous + 1). This keeps repeated updates based on the latest state. Change the state rather than manually changing an unrelated DOM element.

## Types describe expectations

TypeScript adds type information to JavaScript. The annotation number describes the expected kind of value. A type checker can catch mistakes such as treating a number as a message record or using a field that does not exist.

Types do not validate data arriving from a network at runtime. Keep the validation from lesson 11. The browser preview checks behaviour and strips type annotations; run npm run typecheck in the project to get actual TypeScript diagnostics.

## Keep the boundary clear

The component owns its visual state, while a pricing or order function owns its business rule. Props can pass information to a smaller component without making it read arbitrary global state.

Test the behaviour a person sees: adding a message, answering one, resetting, and trying to answer below zero. The project extends this component into the inbox you already built, while retaining accessibility and error states.

## Worked example

```react
import React from "react";
export default function App() {
  const [messages, setMessages] = React.useState<number>(10);
  return <main><h1>Amina’s inbox</h1><output id="count">{messages}</output><button type="button" onClick={() => setMessages(previous => previous + 1)}>Add 1 message</button></main>;
}
```

A real React counter starts at 10 and increases when the button is pressed.

- App is the component rendered by the project.
- useState keeps the count and supplies setMessages.
- The button updates state; JSX uses that state for the visible output.

## Further reading

- [React: your first component](https://react.dev/learn/your-first-component)
- [React with TypeScript](https://react.dev/learn/typescript)
