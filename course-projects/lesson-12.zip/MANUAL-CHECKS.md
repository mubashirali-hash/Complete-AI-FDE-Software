# Inspect the rendered result

- A clear component heading: The rendered component still needs meaningful structure.
- The initial state is visible: The initial interface should reflect the initial state.
- Adding changes the visible state: A real state update must change the rendered output.
- Answering decreases the state: The same state owns both kinds of update.
- Reset returns to the stated initial value: Reset should use the documented initial value.
- Answering cannot make the count negative: A boundary rule should hold across repeated updates.

Check at 320px and 900px widths, with keyboard input. The course browser also executes these behaviour checks. Project acceptance requires the broader tests in PROJECT.md.
