import React from "react";
export default function App() {
  const [messages, setMessages] = React.useState<number>(10);
  return <main><h1>Amina’s inbox</h1><output id="count">{messages}</output><button type="button" onClick={() => setMessages(previous => previous + 1)}>Add 1 message</button><button type="button" onClick={() => setMessages(previous => Math.max(0, previous - 1))}>Answer 1 message</button><button type="button" onClick={() => setMessages(10)}>Start again</button></main>;
}