def exercise(body):
    
    def create_message(body):
        return {"status": 201, "body": {}}
    return (create_message(body))
