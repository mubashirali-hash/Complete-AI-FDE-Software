# A running message service

Use the service workspace in the kit to implement and call a FastAPI endpoint backed by SQLite. Add tests before attaching the website.

The browser exercise is a warm-up. Its passing checks do not prove this project's acceptance. Build the milestones below, run the listed tests, and save your evidence.

## Deliverables

- A running FastAPI application.
- A written request/response contract.
- HTTP tests using a temporary database.

## Milestone 1: Start the service

1. Create a Python virtual environment.
2. Install the pinned requirements.
3. Start the service and inspect /docs.

## Milestone 2: Create and retrieve

1. Validate text with a request model.
2. Save a valid message using a parameterized statement.
3. Return 201 and an id chosen by the service.

## Milestone 3: Test the boundary

1. Send ordinary, blank, over-limit, and extra-field requests.
2. Retrieve the saved record after a restart.
3. Compare each result with the contract.

## Acceptance

- [ ] Requests reach a real HTTP service.
- [ ] A valid message is stored.
- [ ] Invalid input is rejected before storage.
- [ ] Server-owned fields cannot be overwritten.
- [ ] The test suite uses an isolated database.

## Tests to reproduce

- Valid POST: 201 with a server-selected id and trimmed text.
- Blank POST: 422 with no stored record.
- Service restart: The created record remains available.

## Independent extension

Add a separate list endpoint with pagination and a documented maximum page size.

## Explain your work

- How does the browser function differ from an HTTP server?
- Which validation happens before storage?
- What must a client inspect besides the status?
