# Give the shop a real API

The website and shop staff need one service for creating messages. Agree on the exact request before connecting the interface.

## Agree on the boundary

An API lets programs communicate through a contract. POST /messages accepts JSON containing text. A successful response uses 201 and returns a created record. Invalid text uses 422 with a useful explanation.

Keep the contract small: trim outer whitespace, accept 1 to 200 characters, and reject extra fields. The service chooses ids and ownership. Writing examples of accepted and rejected requests prevents frontend and backend from guessing differently.

## Run a real endpoint

FastAPI maps a Python function to an HTTP method and path. A Pydantic model describes allowed fields and performs runtime validation. The project includes a FastAPI service; start it using the README and open /docs to inspect its generated API documentation.

The browser exercise implements the response decision as a function so you can inspect it quickly. It does not listen on a network port. The project requires actual requests to the running service and verifies response status and JSON.

## Validate before saving

JSON being syntactically valid does not make its contents acceptable. Check the object shape, field types, and limits before using the database. Trim first, then measure the remaining text. Reject a whitespace-only message.

Validation errors are expected client outcomes. Internal database failures are different; do not turn every exception into a successful empty list. Avoid returning traceback details to customers. Keep diagnostic details in controlled server logs.

## Prove the contract with requests

Use curl, the API docs, or a small test client to send normal, boundary, and invalid requests. Inspect both HTTP status and body. A response of 201 with the wrong owner is still a bug.

Keep service, data access, and business rules separate enough to test. Use a temporary test database, not a real shop database. Before releasing, document how a client should recover from validation errors and temporary service failures.

## Worked example

```python
def create_message(body):
    if not isinstance(body, dict) or not isinstance(body.get("text"), str):
        return {"status": 422, "body": {"error": "text must be a string"}}
    text = body["text"].strip()
    if not text or len(text) > 200:
        return {"status": 422, "body": {"error": "text must contain 1 to 200 characters"}}
    return {"status": 201, "body": {"text": text}}
print(create_message({"text": " Hello "}))
```

{"status": 201, "body": {"text": "Hello"}}

- The function checks the shape before reading text.
- Trimming happens before the length rule.
- The output includes the status and a predictable body.

## Further reading

- [FastAPI first steps](https://fastapi.tiangolo.com/tutorial/first-steps/)
- [FastAPI request bodies](https://fastapi.tiangolo.com/tutorial/body/)
