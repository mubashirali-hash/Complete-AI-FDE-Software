def exercise(body):
    
    def create_message(body):
        if not isinstance(body, dict) or not isinstance(body.get("text"), str):
            return {"status": 422, "body": {"error": "text must be a string"}}
        if set(body) != {"text"}:
            return {"status": 422, "body": {"error": "unexpected fields"}}
        text = body["text"].strip()
        if not text or len(text) > 200:
            return {"status": 422, "body": {"error": "text must contain 1 to 200 characters"}}
        return {"status": 201, "body": {"text": text}}
    return (create_message(body))
